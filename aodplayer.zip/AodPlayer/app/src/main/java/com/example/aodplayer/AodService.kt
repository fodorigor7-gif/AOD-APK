package com.example.aodplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder

// Когда экран гаснет (телефон заблокирован) — сразу открываем AOD поверх экрана блокировки
class AodService : Service() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF && Prefs.autoOnLock(c)) {
                val a = Intent(c, AodActivity::class.java)
                a.putExtra("fromLock", true)
                a.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
                try {
                    c.startActivity(a)
                } catch (e: Exception) {
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        registerReceiver(receiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("aod", "AOD Плеер", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "aod")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("AOD Плеер работает")
            .setContentText("Включает AOD при блокировке телефона")
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
