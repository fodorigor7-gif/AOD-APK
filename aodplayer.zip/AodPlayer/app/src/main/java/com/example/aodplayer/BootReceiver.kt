package com.example.aodplayer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Prefs.autoOnLock(c)) {
            try {
                c.startForegroundService(Intent(c, AodService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
