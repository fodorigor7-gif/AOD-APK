package com.example.aodplayer

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.FileOutputStream

// Окно «вырезать фото»: двигай и масштабируй фото под круглой рамкой
class CropActivity : Activity() {

    private lateinit var crop: CropView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val uri = intent.data
        val bmp = if (uri != null) loadBitmap(uri) else null
        if (bmp == null) {
            Toast.makeText(this, "Не удалось открыть фото", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val d = resources.displayMetrics.density
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        crop = CropView(this)
        crop.setBitmap(bmp)
        root.addView(crop, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val hint = TextView(this)
        hint.text = "Двигай фото одним пальцем, увеличивай двумя"
        hint.setTextColor(Color.WHITE)
        hint.textSize = 14f
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, (48 * d).toInt(), 0, 0)
        root.addView(hint, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val row = LinearLayout(this)
        row.setPadding((16 * d).toInt(), 0, (16 * d).toInt(), (24 * d).toInt())
        val cancel = Button(this)
        cancel.text = "Отмена"
        cancel.isAllCaps = false
        cancel.setOnClickListener { finish() }
        val done = Button(this)
        done.text = "Готово"
        done.isAllCaps = false
        done.setOnClickListener { save() }
        row.addView(cancel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(done, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        setContentView(root)
    }

    private fun save() {
        val out = crop.crop()
        if (out == null) {
            finish()
            return
        }
        try {
            FileOutputStream(PictureStore.file(this)).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            setResult(RESULT_OK)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось сохранить", Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun loadBitmap(uri: Uri): Bitmap? {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            var orientation = ExifInterface.ORIENTATION_NORMAL
            try {
                contentResolver.openInputStream(uri)?.use {
                    orientation = ExifInterface(it).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            } catch (e: Exception) {
            }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg == 0f) return bmp
            val mx = Matrix()
            mx.postRotate(deg)
            return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
        } catch (e: Exception) {
            return null
        }
    }
}
