package com.example.aodplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

// Фото под круглой рамкой: двигаем одним пальцем, масштабируем двумя
class CropView(ctx: Context) : View(ctx) {

    private var bmp: Bitmap? = null
    private val m = Matrix()
    private var cx = 0f
    private var cy = 0f
    private var r = 0f
    private var minScale = 1f
    private var lastX = 0f
    private var lastY = 0f

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shade = Paint()
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)

    private val scaler = ScaleGestureDetector(ctx,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val cur = currentScale()
                var f = d.scaleFactor
                if (cur * f < minScale) f = minScale / cur
                if (cur * f > minScale * 8f) f = minScale * 8f / cur
                m.postScale(f, f, d.focusX, d.focusY)
                clamp()
                invalidate()
                return true
            }
        })

    init {
        shade.color = Color.argb(185, 0, 0, 0)
        ring.color = Color.WHITE
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = 3 * density
    }

    fun setBitmap(b: Bitmap) {
        bmp = b
        if (width > 0) reset()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cx = w / 2f
        cy = h * 0.45f
        r = minOf(w, h) * 0.42f
        if (bmp != null) reset()
    }

    private fun reset() {
        val b = bmp ?: return
        minScale = maxOf(2 * r / b.width, 2 * r / b.height)
        m.reset()
        m.postScale(minScale, minScale)
        m.postTranslate(cx - b.width * minScale / 2, cy - b.height * minScale / 2)
    }

    private fun currentScale(): Float {
        val v = FloatArray(9)
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    private fun clamp() {
        val b = bmp ?: return
        val rect = RectF(0f, 0f, b.width.toFloat(), b.height.toFloat())
        m.mapRect(rect)
        var dx = 0f
        var dy = 0f
        if (rect.left > cx - r) dx = (cx - r) - rect.left
        if (rect.right < cx + r) dx = (cx + r) - rect.right
        if (rect.top > cy - r) dy = (cy - r) - rect.top
        if (rect.bottom < cy + r) dy = (cy + r) - rect.bottom
        m.postTranslate(dx, dy)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1 && !scaler.isInProgress) {
                    m.postTranslate(e.x - lastX, e.y - lastY)
                    clamp()
                    invalidate()
                }
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (e.actionIndex == 0) 1 else 0
                lastX = e.getX(i)
                lastY = e.getY(i)
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.BLACK)
        val b = bmp ?: return
        c.drawBitmap(b, m, paint)
        val p = Path()
        p.fillType = Path.FillType.EVEN_ODD
        p.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
        p.addCircle(cx, cy, r, Path.Direction.CCW)
        c.drawPath(p, shade)
        c.drawCircle(cx, cy, r, ring)
    }

    // Вырезает то, что внутри круга, в квадрат out x out
    fun crop(out: Int = 600): Bitmap? {
        val b = bmp ?: return null
        val res = Bitmap.createBitmap(out, out, Bitmap.Config.ARGB_8888)
        val c = Canvas(res)
        val mm = Matrix(m)
        mm.postTranslate(-(cx - r), -(cy - r))
        val k = out / (2 * r)
        mm.postScale(k, k)
        c.drawBitmap(b, mm, paint)
        return res
    }
}
