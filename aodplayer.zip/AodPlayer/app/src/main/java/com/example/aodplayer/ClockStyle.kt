package com.example.aodplayer

import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.widget.TextView
import java.io.File

// Оформление часов: свой файл шрифта, толщина, расстояние между цифрами
object ClockStyle {
    fun file(ctx: Context): File = File(ctx.filesDir, "clock_font.ttf")
    fun hasCustom(ctx: Context): Boolean = file(ctx).exists()

    fun typeface(ctx: Context): Typeface {
        val w = Prefs.clockWeight(ctx)
        val f = file(ctx)
        if (f.exists()) {
            try {
                val tf = Typeface.Builder(f).setFontVariationSettings("'wght' $w").build()
                if (tf != null) return tf
            } catch (e: Exception) {
            }
        }
        return system(w)
    }

    private fun system(w: Int): Typeface {
        val base = Typeface.create("sans-serif", Typeface.NORMAL)
        if (Build.VERSION.SDK_INT >= 28) return Typeface.create(base, w, false)
        return when {
            w < 200 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
            w < 350 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            w < 600 -> base
            else -> Typeface.create(base, Typeface.BOLD)
        }
    }

    fun apply(ctx: Context, tv: TextView) {
        tv.typeface = typeface(ctx)
        tv.letterSpacing = Prefs.clockSpacing(ctx) / 100f
    }
}
