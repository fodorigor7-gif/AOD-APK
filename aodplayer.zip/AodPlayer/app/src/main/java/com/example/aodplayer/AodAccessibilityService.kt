package com.example.aodplayer

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

// Открывает AOD, когда одновременно зажаты обе кнопки громкости
class AodAccessibilityService : AccessibilityService() {

    private var upDown = false
    private var downDown = false
    private var fired = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!Prefs.volLaunch(this)) return false
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        if (code == KeyEvent.KEYCODE_VOLUME_UP) upDown = down else downDown = down

        if (upDown && downDown) {
            if (!fired) {
                fired = true
                val i = Intent(this, AodActivity::class.java)
                i.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
                try {
                    startActivity(i)
                } catch (e: Exception) {
                }
            }
            return true
        }
        if (!upDown && !downDown) fired = false
        return false
    }
}
