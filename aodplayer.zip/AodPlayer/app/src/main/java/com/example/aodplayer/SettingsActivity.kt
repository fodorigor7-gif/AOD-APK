package com.example.aodplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

// Настройки в стиле One UI: тёмный фон, крупный заголовок, скруглённые блоки
class SettingsActivity : Activity() {

    private val ACCENT = Color.rgb(62, 145, 255)
    private val CARD = Color.rgb(28, 28, 30)
    private val TXT = Color.rgb(240, 240, 240)
    private val SUB = Color.rgb(150, 150, 156)
    private val LINE = Color.rgb(46, 46, 48)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var col: LinearLayout
    private var preview: TextView? = null
    private var luxText: TextView? = null
    private var sm: SensorManager? = null

    private val lightListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            luxText?.text = "Сейчас: ${e.values[0].roundToInt()} лк"
        }

        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(40))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(col)

        // Крупный заголовок как в One UI
        val big = TextView(this)
        big.text = "Настройки"
        big.textSize = 36f
        big.setTextColor(TXT)
        big.setPadding(dp(12), dp(60), 0, 0)
        col.addView(big)
        val small = TextView(this)
        small.text = "AOD Плеер"
        small.textSize = 14f
        small.setTextColor(SUB)
        small.setPadding(dp(12), dp(2), 0, dp(8))
        col.addView(small)

        buildElements()
        buildPlayer()
        buildClock()
        buildBrightness()
        buildProximity()
        buildWeather()
        buildCalendarAndScreen()

        val hint = TextView(this)
        hint.text = "Открыть эти настройки из AOD: 5 раз нажать на часы и зажать на 3 секунды.\nКнопка «Назад» возвращает к AOD."
        hint.textSize = 12f
        hint.setTextColor(SUB)
        hint.setPadding(dp(12), dp(16), dp(12), 0)
        col.addView(hint)

        setContentView(scroll)
    }

    // ---------- блоки настроек ----------

    private fun buildElements() {
        addHeader("Элементы на экране")
        val rows = ArrayList<View>()
        for (id in Prefs.ALL) {
            rows.add(switchRow(Prefs.title(id), null, Prefs.enabled(this, id)) {
                Prefs.setEnabled(this, id, it)
            })
        }
        rows.add(row("Расположение и размер", "Перетаскивай элементы пальцем, меняй размер") {
            val i = Intent(this, AodActivity::class.java)
            i.putExtra("edit", true)
            startActivity(i)
        })
        rows.add(row("Сбросить расположение", "Вернуть всё на места по умолчанию") {
            Prefs.resetPlacement(this)
            Toast.makeText(this, "Сброшено", Toast.LENGTH_SHORT).show()
        })
        addCard(*rows.toTypedArray())
    }

    private fun buildPlayer() {
        addHeader("Плеер")
        val opts = optionRows(
            listOf(
                Pair("Обычный", "Обложка, название и кнопки"),
                Pair("Без обложки", "Только название и кнопки"),
                Pair("Обложка на весь экран", "Фон цвета альбома, размытые края, тёмные границы")
            ),
            Prefs.playerStyle(this)
        ) { Prefs.setPlayerStyle(this, it) }
        addCard(*opts.toTypedArray())
        addCard(
            row("Доступ к уведомлениям", "Нужен, чтобы видеть, что сейчас играет") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        )
    }

    private fun buildClock() {
        addHeader("Часы")
        val pv = TextView(this)
        pv.text = "12:34"
        pv.textSize = 56f
        pv.setTextColor(Color.rgb(200, 200, 200))
        pv.gravity = Gravity.CENTER
        pv.setPadding(0, dp(18), 0, dp(10))
        ClockStyle.apply(this, pv)
        preview = pv

        addCard(
            pv,
            row("Свой шрифт", if (ClockStyle.hasCustom(this)) "Загружен свой файл" else "Стандартный") {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                startActivityForResult(i, 10)
            },
            row("Вернуть стандартный шрифт") {
                ClockStyle.file(this).delete()
                refreshPreview()
                Toast.makeText(this, "Шрифт сброшен", Toast.LENGTH_SHORT).show()
            },
            slider("Толщина", { "${100 + it * 10}" }, 80, (Prefs.clockWeight(this) - 100) / 10) {
                Prefs.setClockWeight(this, 100 + it * 10)
                refreshPreview()
            },
            slider("Расстояние между цифрами", { "${it - 10}" }, 70, Prefs.clockSpacing(this) + 10) {
                Prefs.setClockSpacing(this, it - 10)
                refreshPreview()
            }
        )
    }

    private fun buildBrightness() {
        addHeader("Яркость")
        addCard(
            switchRow("Автояркость по датчику света", "Яркость сама подстраивается под освещение",
                Prefs.autoBright(this)) { Prefs.setAutoBright(this, it) },
            slider("Яркость, если автояркость выключена", { "${it + 1}%" }, 99,
                Prefs.brightness(this) - 1) { Prefs.setBrightness(this, it + 1) }
        )

        addHeader("Уровни автояркости")
        val luxRow = row("Освещённость", "Сейчас: —")
        luxText = luxRow.findViewWithTag("sub")
        addCard(
            luxRow,
            slider("Яркость в темноте", { "${it + 1}%" }, 99, Prefs.brDark(this) - 1) {
                Prefs.setBrDark(this, it + 1)
            },
            slider("Яркость при обычном свете", { "${it + 1}%" }, 99, Prefs.brMid(this) - 1) {
                Prefs.setBrMid(this, it + 1)
            },
            slider("Яркость на ярком свету", { "${it + 1}%" }, 99, Prefs.brBright(this) - 1) {
                Prefs.setBrBright(this, it + 1)
            },
            slider("Порог «темно» (до)", { "${it + 1} лк" }, 199, Prefs.luxLow(this) - 1) {
                Prefs.setLuxLow(this, it + 1)
            },
            slider("Порог «ярко» (от)", { "${200 + it * 100} лк" }, 98,
                ((Prefs.luxHigh(this) - 200) / 100).coerceIn(0, 98)) {
                Prefs.setLuxHigh(this, 200 + it * 100)
            }
        )
    }

    private fun buildProximity() {
        addHeader("Датчик приближения")
        addCard(
            switchRow("Гасить экран, если датчик закрыт",
                "Закрыл рукой или приложил к уху — экран становится чёрным",
                Prefs.proximity(this)) { Prefs.setProximity(this, it) }
        )
    }

    private fun buildWeather() {
        addHeader("Погода")
        val city = EditText(this)
        city.hint = "Не задан"
        city.setHintTextColor(Color.GRAY)
        city.setTextColor(TXT)
        city.setSingleLine()
        city.gravity = Gravity.END
        city.minWidth = dp(140)
        city.background = null
        city.setText(Prefs.city(this))
        city.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                Prefs.setCity(this@SettingsActivity, s?.toString()?.trim() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        addCard(
            switchRow("Определять местоположение автоматически",
                "Выключи, чтобы задать город вручную", Prefs.autoLoc(this)) {
                Prefs.setAutoLoc(this, it)
            },
            row("Доступ к местоположению", "С ним город определяется точнее, без него — по IP") {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 2)
            },
            row("Город вручную", "Работает, если автоопределение выключено", city),
            row("Проверить погоду сейчас", "Загрузит данные заново из нескольких источников") {
                Toast.makeText(this, "Загружаю…", Toast.LENGTH_SHORT).show()
                Thread {
                    val r = try {
                        Weather.load(applicationContext)
                    } catch (e: Exception) {
                        null
                    }
                    if (r != null) Prefs.setWeather(this, Weather.cacheKey(this), r)
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            r ?: "Не удалось получить погоду. Проверь интернет и город.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }.start()
            }
        )
    }

    private fun buildCalendarAndScreen() {
        addHeader("Календарь")
        addCard(
            row("Доступ к календарю", "Для виджета ближайших событий") {
                requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 1)
            }
        )
        addHeader("Экран")
        addCard(
            switchRow("Защита от выгорания", "Картинка слегка сдвигается раз в минуту",
                Prefs.shift(this)) { Prefs.setShift(this, it) }
        )
    }

    // ---------- шрифт ----------

    private fun refreshPreview() {
        preview?.let { ClockStyle.apply(this, it) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 10 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                ClockStyle.file(this).outputStream().use { out -> input.copyTo(out) }
            }
            refreshPreview()
            Toast.makeText(this, "Шрифт загружен", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось прочитать файл", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- датчик света для подсказки ----------

    override fun onResume() {
        super.onResume()
        val m = getSystemService(SENSOR_SERVICE) as SensorManager
        sm = m
        val s = m.getDefaultSensor(Sensor.TYPE_LIGHT)
        if (s != null) m.registerListener(lightListener, s, SensorManager.SENSOR_DELAY_NORMAL)
        else luxText?.text = "Датчика света нет"
    }

    override fun onPause() {
        super.onPause()
        sm?.unregisterListener(lightListener)
    }

    // ---------- строительные блоки интерфейса ----------

    private fun addHeader(t: String) {
        val h = TextView(this)
        h.text = t
        h.textSize = 13f
        h.setTextColor(ACCENT)
        h.setPadding(dp(12), dp(22), 0, dp(8))
        col.addView(h)
    }

    private fun addCard(vararg rows: View) {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(CARD)
        bg.cornerRadius = dp(26).toFloat()
        c.background = bg
        c.clipToOutline = true
        rows.forEachIndexed { i, r ->
            if (i > 0) {
                val line = View(this)
                line.setBackgroundColor(LINE)
                val lp = LinearLayout.LayoutParams(MATCH, 1)
                lp.leftMargin = dp(20)
                lp.rightMargin = dp(20)
                c.addView(line, lp)
            }
            c.addView(r)
        }
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(4)
        col.addView(c, lp)
    }

    private fun ripple(): Drawable? {
        val ta = obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground))
        val d = ta.getDrawable(0)
        ta.recycle()
        return d
    }

    private fun row(
        title: String,
        sub: String? = null,
        trailing: View? = null,
        onClick: (() -> Unit)? = null
    ): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(20), dp(14), dp(20), dp(14))

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 16f
        t.setTextColor(TXT)
        texts.addView(t)
        if (sub != null) {
            val s = TextView(this)
            s.text = sub
            s.textSize = 13f
            s.setTextColor(SUB)
            s.tag = "sub"
            s.setPadding(0, dp(2), 0, 0)
            texts.addView(s)
        }
        r.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (trailing != null) r.addView(trailing, LinearLayout.LayoutParams(WRAP, WRAP))
        if (onClick != null) {
            r.setOnClickListener { onClick() }
            r.background = ripple()
        }
        return r
    }

    private fun switchRow(
        title: String,
        sub: String?,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ): LinearLayout {
        val sw = Switch(this)
        sw.isChecked = checked
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, Color.rgb(210, 210, 212)))
        sw.trackTintList = ColorStateList(st, intArrayOf(ACCENT, Color.rgb(80, 80, 84)))
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        return row(title, sub, sw) { sw.toggle() }
    }

    private fun slider(
        title: String,
        valueText: (Int) -> String,
        max: Int,
        progress: Int,
        onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(14), dp(20), dp(10))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this)
        t.text = title
        t.textSize = 16f
        t.setTextColor(TXT)
        val v = TextView(this)
        v.textSize = 14f
        v.setTextColor(ACCENT)
        v.text = valueText(progress)
        head.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(v)

        val s = SeekBar(this)
        s.max = max
        s.progress = progress
        s.progressTintList = ColorStateList.valueOf(ACCENT)
        s.thumbTintList = ColorStateList.valueOf(ACCENT)
        s.progressBackgroundTintList = ColorStateList.valueOf(Color.rgb(70, 70, 74))
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                v.text = valueText(p)
                onChange(p)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        box.addView(head)
        box.addView(s)
        return box
    }

    private fun optionRows(
        options: List<Pair<String, String>>,
        selected: Int,
        onSel: (Int) -> Unit
    ): List<View> {
        val radios = ArrayList<RadioButton>()
        val rows = ArrayList<View>()
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        options.forEachIndexed { i, opt ->
            val rb = RadioButton(this)
            rb.isClickable = false
            rb.isFocusable = false
            rb.buttonTintList = ColorStateList(st, intArrayOf(ACCENT, Color.GRAY))
            rb.isChecked = i == selected
            radios.add(rb)
            rows.add(row(opt.first, opt.second, rb) {
                radios.forEachIndexed { j, r -> r.isChecked = j == i }
                onSel(i)
            })
        }
        return rows
    }
}
