package com.example.aodplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class SettingsActivity : Activity() {

    private val FG = Color.rgb(220, 220, 220)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, (40 * d).toInt(), pad, pad)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(col)

        col.addView(label("Настройки AOD", 24f))
        col.addView(label("Открыть настройки из AOD: 5 раз нажать на часы, потом зажать на 3 секунды."))

        col.addView(button("Доступ к уведомлениям (для плеера)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("Доступ к календарю (для виджета)") {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 1)
        })

        col.addView(button("Расположение и размер элементов") {
            val i = Intent(this, AodActivity::class.java)
            i.putExtra("edit", true)
            startActivity(i)
        })
        col.addView(button("Сбросить расположение и размеры") {
            Prefs.resetPlacement(this)
        })

        val brLabel = label("Яркость: ${Prefs.brightness(this)}%")
        col.addView(brLabel)
        col.addView(seek(99, Prefs.brightness(this) - 1) { p ->
            Prefs.setBrightness(this, p + 1)
            brLabel.text = "Яркость: ${p + 1}%"
        })

        col.addView(label("Что показывать"))
        for (id in Prefs.ALL) {
            val cb = CheckBox(this)
            cb.text = Prefs.title(id)
            cb.setTextColor(FG)
            cb.isChecked = Prefs.enabled(this, id)
            cb.setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this, id, v) }
            col.addView(cb)
        }

        col.addView(label("Город для погоды"))
        val city = EditText(this)
        city.hint = "Например: Москва"
        city.setHintTextColor(Color.GRAY)
        city.setTextColor(FG)
        city.setSingleLine()
        city.setText(Prefs.city(this))
        city.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                Prefs.setCity(this@SettingsActivity, s?.toString()?.trim() ?: "")
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(city)

        val shift = CheckBox(this)
        shift.text = "Сдвигать картинку раз в минуту (защита от выгорания)"
        shift.setTextColor(FG)
        shift.isChecked = Prefs.shift(this)
        shift.setOnCheckedChangeListener { _, v -> Prefs.setShift(this, v) }
        col.addView(shift)

        col.addView(button("Готово — вернуться к AOD") { finish() })

        setContentView(scroll)
    }

    private fun label(t: String, size: Float = 15f): TextView {
        val d = resources.displayMetrics.density
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(FG)
        v.setPadding(0, (14 * d).toInt(), 0, (4 * d).toInt())
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = max
        s.progress = progress
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = onChange(p)
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }
}
