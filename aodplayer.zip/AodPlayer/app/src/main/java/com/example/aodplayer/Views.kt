package com.example.aodplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

// Чёрно-белые кнопки плеера, нарисованные вручную (без эмодзи)
class IconButton(context: Context, private var kind: Int) : View(context) {
    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(170, 170, 170)
        style = Paint.Style.FILL
    }

    fun show(k: Int) {
        if (kind != k) {
            kind = k
            invalidate()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = (68 * resources.displayMetrics.density).toInt()
        setMeasuredDimension(s, s)
    }

    private fun tri(c: Canvas, u: Float, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        val p = Path()
        p.moveTo(x1 * u, y1 * u)
        p.lineTo(x2 * u, y2 * u)
        p.lineTo(x3 * u, y3 * u)
        p.close()
        c.drawPath(p, paint)
    }

    override fun onDraw(c: Canvas) {
        val u = width / 100f
        when (kind) {
            PLAY -> tri(c, u, 34f, 22f, 34f, 78f, 80f, 50f)
            PAUSE -> {
                c.drawRect(30 * u, 22 * u, 44 * u, 78 * u, paint)
                c.drawRect(56 * u, 22 * u, 70 * u, 78 * u, paint)
            }
            PREV -> {
                c.drawRect(22 * u, 28 * u, 30 * u, 72 * u, paint)
                tri(c, u, 76f, 28f, 76f, 72f, 36f, 50f)
            }
            NEXT -> {
                c.drawRect(70 * u, 28 * u, 78 * u, 72 * u, paint)
                tri(c, u, 24f, 28f, 24f, 72f, 64f, 50f)
            }
        }
    }
}

// Мини-календарь на месяц
class MonthView(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gray = Color.rgb(170, 170, 170)
    private val dim = Color.rgb(110, 110, 110)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((280 * d).toInt(), (205 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val cal = Calendar.getInstance()
        val today = cal.get(Calendar.DAY_OF_MONTH)
        val month = SimpleDateFormat("LLLL yyyy", Locale.forLanguageTag("ru")).format(cal.time)
        p.textAlign = Paint.Align.CENTER
        p.style = Paint.Style.FILL

        p.color = gray
        p.textSize = 15 * d
        c.drawText(month.replaceFirstChar { it.uppercase() }, width / 2f, 18 * d, p)

        val cell = width / 7f
        p.color = dim
        p.textSize = 12 * d
        val names = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
        for (i in 0 until 7) c.drawText(names[i], cell * i + cell / 2, 42 * d, p)

        val first = cal.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

        p.textSize = 14 * d
        for (day in 1..days) {
            val idx = offset + day - 1
            val x = cell * (idx % 7) + cell / 2
            val y = 68 * d + (idx / 7) * 25 * d
            if (day == today) {
                p.color = gray
                p.style = Paint.Style.STROKE
                p.strokeWidth = 1.5f * d
                c.drawCircle(x, y - 5 * d, 12 * d, p)
                p.style = Paint.Style.FILL
            } else {
                p.color = dim
            }
            if (day == today) p.color = gray
            c.drawText(day.toString(), x, y, p)
        }
    }
}
