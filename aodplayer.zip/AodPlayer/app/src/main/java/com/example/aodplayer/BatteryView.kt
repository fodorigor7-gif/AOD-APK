package com.example.aodplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.TypedValue
import android.view.View

// Значок батареи + число, как на Huawei: [▮▮▮▯] 89
class BatteryView(ctx: Context) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val gray = Color.rgb(170, 170, 170)

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val iconW = 34 * d
    private val iconH = 16 * d
    private val nubW = 3 * d
    private val gap = 8 * d

    var level: Int = -1
        set(v) {
            field = v
            requestLayout()
            invalidate()
        }

    var charging: Boolean = false
        set(v) {
            field = v
            invalidate()
        }

    init {
        textPaint.color = gray
        textPaint.textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 22f, resources.displayMetrics
        )
        textPaint.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        strokePaint.color = gray
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeWidth = 2 * d
        fillPaint.color = gray
        fillPaint.style = Paint.Style.FILL
        boltPaint.color = Color.BLACK
        boltPaint.style = Paint.Style.FILL
    }

    private fun label(): String = if (level >= 0) level.toString() else "--"

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val tw = textPaint.measureText(label())
        val fm = textPaint.fontMetrics
        val th = fm.descent - fm.ascent
        val w = (iconW + nubW + gap + tw + 2 * d).toInt() + 1
        val h = maxOf(th, iconH + 4 * d).toInt() + 1
        setMeasuredDimension(w, h)
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        val top = cy - iconH / 2
        val bottom = cy + iconH / 2
        val half = strokePaint.strokeWidth / 2

        c.drawRoundRect(RectF(half, top + half, iconW - half, bottom - half), 4 * d, 4 * d, strokePaint)
        c.drawRoundRect(RectF(iconW, cy - 3.5f * d, iconW + nubW, cy + 3.5f * d), 1.5f * d, 1.5f * d, fillPaint)

        val inset = strokePaint.strokeWidth + 1.5f * d
        val l = level.coerceIn(0, 100)
        val fw = (iconW - 2 * inset) * l / 100f
        if (fw > 0f) {
            c.drawRoundRect(RectF(inset, top + inset, inset + fw, bottom - inset), 2 * d, 2 * d, fillPaint)
        }

        if (charging) {
            val bx = iconW / 2
            val s = iconH * 0.32f
            val p = Path()
            p.moveTo(bx + s * 0.2f, cy - s * 1.2f)
            p.lineTo(bx - s * 0.7f, cy + s * 0.15f)
            p.lineTo(bx - s * 0.05f, cy + s * 0.15f)
            p.lineTo(bx - s * 0.2f, cy + s * 1.2f)
            p.lineTo(bx + s * 0.7f, cy - s * 0.15f)
            p.lineTo(bx + s * 0.05f, cy - s * 0.15f)
            p.close()
            c.drawPath(p, boltPaint)
        }

        val fm = textPaint.fontMetrics
        val baseline = cy - (fm.ascent + fm.descent) / 2
        c.drawText(label(), iconW + nubW + gap, baseline, textPaint)
    }
}
