package com.example.aodplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.TypedValue
import android.view.View

// Батарея в трёх видах:
// 0 — только иконка; 1 — число внутри иконки; 2 — «89%» слева и иконка справа.
// Цвет заполнения: зелёный при зарядке, красный < 20%, оранжевый < 30%.
// Молния (зарядка) и листик (экономия): внутри иконки, если внутри нет числа,
// и справа от иконки, если число внутри.
class BatteryView(ctx: Context) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val gray = Color.rgb(170, 170, 170)
    private val light = Color.rgb(215, 215, 215)
    private val green = Color.rgb(76, 217, 100)
    private val orange = Color.rgb(255, 159, 10)
    private val red = Color.rgb(255, 69, 58)

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val insidePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glyphPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    var style: Int = 2
        set(v) {
            field = v
            requestLayout()
            invalidate()
        }
    var level: Int = -1
        set(v) {
            field = v
            requestLayout()
            invalidate()
        }
    var charging: Boolean = false
        set(v) {
            field = v
            requestLayout()
            invalidate()
        }
    var saver: Boolean = false
        set(v) {
            field = v
            requestLayout()
            invalidate()
        }

    init {
        textPaint.textSize = sp(20f)
        textPaint.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        insidePaint.textSize = sp(13f)
        insidePaint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        insidePaint.textAlign = Paint.Align.CENTER
        strokePaint.style = Paint.Style.STROKE
        strokePaint.strokeWidth = 2 * d
        strokePaint.color = gray
        fillPaint.style = Paint.Style.FILL
        glyphPaint.style = Paint.Style.FILL
    }

    private fun sp(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    private fun iconW(): Float = if (style == 1) 48 * d else 36 * d
    private fun iconH(): Float = if (style == 1) 24 * d else 17 * d
    private val nubW = 3 * d
    private val gap = 8 * d

    private fun fillColor(): Int = when {
        charging -> green
        level in 0..19 -> red
        level in 0..29 -> orange
        else -> gray
    }

    private fun percentText(): String = if (level >= 0) "$level%" else "--%"
    private fun numberText(): String = if (level >= 0) level.toString() else "--"

    private fun sideGlyphs(): Int = if (style == 1) (if (saver) 1 else 0) + (if (charging) 1 else 0) else 0

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        var w = iconW() + nubW + 2 * d
        var h = iconH() + 4 * d
        if (style == 2) {
            w += textPaint.measureText(percentText()) + gap
            val fm = textPaint.fontMetrics
            h = maxOf(h, fm.descent - fm.ascent)
        }
        w += sideGlyphs() * (iconH() * 0.8f + gap)
        setMeasuredDimension(w.toInt() + 1, h.toInt() + 1)
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        var x = 0f

        if (style == 2) {
            val low = !charging && level in 0..29
            textPaint.color = if (low) fillColor() else gray
            val fm = textPaint.fontMetrics
            c.drawText(percentText(), x, cy - (fm.ascent + fm.descent) / 2, textPaint)
            x += textPaint.measureText(percentText()) + gap
        }

        val iw = iconW()
        val ih = iconH()
        val top = cy - ih / 2
        val bottom = cy + ih / 2
        val half = strokePaint.strokeWidth / 2

        // корпус и «носик»
        c.drawRoundRect(RectF(x + half, top + half, x + iw - half, bottom - half),
            4 * d, 4 * d, strokePaint)
        fillPaint.color = gray
        c.drawRoundRect(RectF(x + iw, cy - 3.5f * d, x + iw + nubW, cy + 3.5f * d),
            1.5f * d, 1.5f * d, fillPaint)

        // заполнение
        val inset = strokePaint.strokeWidth + 1.5f * d
        val l = level.coerceIn(0, 100)
        val fw = (iw - 2 * inset) * l / 100f
        val fillRect = RectF(x + inset, top + inset, x + inset + fw, bottom - inset)
        if (fw > 0f) {
            fillPaint.color = fillColor()
            c.drawRoundRect(fillRect, 2 * d, 2 * d, fillPaint)
        }

        val icx = x + iw / 2
        if (style == 1) {
            // число внутри иконки: на заполненной части чёрное, на пустой светлое
            val fm = insidePaint.fontMetrics
            val baseline = cy - (fm.ascent + fm.descent) / 2
            twoTone(c, fillRect) { col ->
                insidePaint.color = col
                c.drawText(numberText(), icx, baseline, insidePaint)
            }
            // молния и листик — справа от иконки
            var gx = x + iw + nubW + gap + iconH() * 0.4f
            val gs = iconH() * 0.34f
            if (saver) {
                glyphPaint.color = green
                leaf(c, gx, cy, gs)
                gx += iconH() * 0.8f + gap
            }
            if (charging) {
                glyphPaint.color = green
                bolt(c, gx, cy, gs)
            }
        } else {
            // внутри иконки — молния (зарядка) или листик (экономия)
            val gs = ih * 0.28f
            if (charging) {
                twoTone(c, fillRect) { col ->
                    glyphPaint.color = col
                    bolt(c, icx, cy, gs)
                }
            } else if (saver) {
                twoTone(c, fillRect) { col ->
                    glyphPaint.color = col
                    leaf(c, icx, cy, gs)
                }
            }
        }
    }

    // Рисует одно и то же дважды: тёмным поверх заполнения и светлым там, где пусто
    private fun twoTone(c: Canvas, fill: RectF, draw: (Int) -> Unit) {
        c.save()
        c.clipRect(fill)
        draw(Color.BLACK)
        c.restore()
        c.save()
        c.clipOutRect(fill)
        draw(light)
        c.restore()
    }

    private fun bolt(c: Canvas, cx: Float, cy: Float, s: Float) {
        val p = Path()
        p.moveTo(cx + s * 0.2f, cy - s * 1.2f)
        p.lineTo(cx - s * 0.7f, cy + s * 0.15f)
        p.lineTo(cx - s * 0.05f, cy + s * 0.15f)
        p.lineTo(cx - s * 0.2f, cy + s * 1.2f)
        p.lineTo(cx + s * 0.7f, cy - s * 0.15f)
        p.lineTo(cx + s * 0.05f, cy - s * 0.15f)
        p.close()
        c.drawPath(p, glyphPaint)
    }

    private fun leaf(c: Canvas, cx: Float, cy: Float, s: Float) {
        val p = Path()
        p.moveTo(cx - s * 0.8f, cy + s * 0.8f)
        p.cubicTo(cx - s * 0.9f, cy - s * 0.1f, cx - s * 0.1f, cy - s * 0.9f, cx + s * 0.9f, cy - s * 0.9f)
        p.cubicTo(cx + s * 0.9f, cy - s * 0.1f, cx + s * 0.2f, cy + s * 0.9f, cx - s * 0.8f, cy + s * 0.8f)
        p.close()
        c.drawPath(p, glyphPaint)
    }
}
