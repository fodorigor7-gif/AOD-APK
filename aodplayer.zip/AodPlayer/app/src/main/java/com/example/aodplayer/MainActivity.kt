package com.example.aodplayer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(60, 60, 60, 60)
            setBackgroundColor(Color.BLACK)
        }
        val info = TextView(this).apply {
            text = "1. Дай доступ к уведомлениям (нужен, чтобы видеть плеер).\n2. Нажми «Запустить AOD».\n\nЗакрыть AOD — тап по часам."
            setTextColor(Color.LTGRAY)
            textSize = 16f
        }
        val access = Button(this).apply {
            text = "Доступ к уведомлениям"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "Запустить AOD"
            setOnClickListener { startActivity(Intent(this@MainActivity, AodActivity::class.java)) }
        }
        root.addView(info)
        root.addView(access)
        root.addView(start)
        setContentView(root)
    }
}
