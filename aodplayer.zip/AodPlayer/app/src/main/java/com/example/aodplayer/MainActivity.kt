package com.example.aodplayer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.Collections

class MainActivity : Activity() {

    private val FG = Color.rgb(220, 220, 220)
    private lateinit var modulesBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, (40 * d).toInt(), pad, pad)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(col)

        col.addView(label("AOD Плеер", 24f))

        col.addView(button("1. Доступ к уведомлениям (для плеера)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("Запустить AOD") {
            startActivity(Intent(this, AodActivity::class.java))
        })
        col.addView(label("Закрыть AOD — тап по пустому месту или по часам."))

        // Яркость
        val brLabel = label("Яркость: ${Prefs.brightness(this)}%")
        col.addView(brLabel)
        col.addView(seek(99, Prefs.brightness(this) - 1) { p ->
            Prefs.setBrightness(this, p + 1)
            brLabel.text = "Яркость: ${p + 1}%"
        })

        // Размер часов
        val csLabel = label("Размер часов: ${Prefs.clockSize(this)}")
        col.addView(csLabel)
        col.addView(seek(100, Prefs.clockSize(this) - 40) { p ->
            Prefs.setClockSize(this, p + 40)
            csLabel.text = "Размер часов: ${p + 40}"
        })

        // Положение
        col.addView(label("Положение по вертикали"))
        col.addView(radios(listOf("Верх", "Центр", "Низ"), Prefs.vAlign(this)) {
            Prefs.setVAlign(this, it)
        })
        col.addView(label("Положение по горизонтали"))
        col.addView(radios(listOf("Лево", "Центр", "Право"), Prefs.hAlign(this)) {
            Prefs.setHAlign(this, it)
        })

        // Виджеты
        col.addView(label("Виджеты (галочка — показывать, стрелки — порядок)"))
        modulesBox = LinearLayout(this)
        modulesBox.orientation = LinearLayout.VERTICAL
        col.addView(modulesBox)
        rebuildModules()

        // Погода
        col.addView(label("Город для погоды"))
        val city = EditText(this)
        city.hint = "Например: Москва"
        city.setHintTextColor(Color.GRAY)
        city.setTextColor(FG)
        city.setSingleLine()
        city.setText(Prefs.city(this))
        city.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                Prefs.setCity(this@MainActivity, s?.toString()?.trim() ?: "")
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(city)

        // Календарь
        col.addView(button("Доступ к календарю (для виджета)") {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 1)
        })

        // Выгорание
        val shift = CheckBox(this)
        shift.text = "Сдвигать картинку раз в минуту (защита от выгорания)"
        shift.setTextColor(FG)
        shift.isChecked = Prefs.shift(this)
        shift.setOnCheckedChangeListener { _, v -> Prefs.setShift(this, v) }
        col.addView(shift)

        setContentView(scroll)
    }

    private fun label(t: String, size: Float = 15f): TextView {
        val d = resources.displayMetrics.density
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(FG)
        v.setPadding(0, (14 * d).toInt(), 0, (4 * d).toInt())
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = max
        s.progress = progress
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) = onChange(p)
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    private fun radios(options: List<String>, selected: Int, onSel: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.HORIZONTAL
        options.forEachIndexed { i, name ->
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = name
            rb.setTextColor(FG)
            g.addView(rb)
            if (i == selected) rb.isChecked = true
        }
        g.setOnCheckedChangeListener { grp, id ->
            onSel(grp.indexOfChild(grp.findViewById(id)))
        }
        return g
    }

    private fun rebuildModules() {
        modulesBox.removeAllViews()
        val order = Prefs.order(this)
        order.forEachIndexed { i, id ->
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL

            val cb = CheckBox(this)
            cb.text = Prefs.title(id)
            cb.setTextColor(FG)
            cb.isChecked = Prefs.enabled(this, id)
            cb.setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this, id, v) }
            row.addView(cb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            row.addView(button("↑") {
                if (i > 0) {
                    Collections.swap(order, i, i - 1)
                    Prefs.setOrder(this, order)
                    rebuildModules()
                }
            })
            row.addView(button("↓") {
                if (i < order.size - 1) {
                    Collections.swap(order, i, i + 1)
                    Prefs.setOrder(this, order)
                    rebuildModules()
                }
            })
            modulesBox.addView(row)
        }
    }
}
