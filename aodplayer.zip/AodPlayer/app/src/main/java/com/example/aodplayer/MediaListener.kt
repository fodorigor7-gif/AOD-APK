package com.example.aodplayer

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// Даёт доступ к медиа-сессиям и к списку уведомлений
class MediaListener : NotificationListenerService() {

    companion object {
        @Volatile var instance: MediaListener? = null
        @Volatile var onChanged: (() -> Unit)? = null
    }

    override fun onListenerConnected() {
        instance = this
        onChanged?.invoke()
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        onChanged?.invoke()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        onChanged?.invoke()
    }
}
