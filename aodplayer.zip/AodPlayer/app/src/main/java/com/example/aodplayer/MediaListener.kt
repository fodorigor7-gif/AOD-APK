package com.example.aodplayer

import android.service.notification.NotificationListenerService

// Пустой сервис: нужен только чтобы система дала доступ к активным медиа-сессиям
class MediaListener : NotificationListenerService()
