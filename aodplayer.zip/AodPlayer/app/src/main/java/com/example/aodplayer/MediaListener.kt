package com.example.aodplayer

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// Даёт доступ к медиа-сессиям (плеер) и к списку уведомлений (значки)
class MediaListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: MediaListener? = null

        @Volatile
        var onChange: (() -> Unit)? = null
    }

    override fun onListenerConnected() {
        instance = this
        onChange?.invoke()
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        onChange?.invoke()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        onChange?.invoke()
    }
}
