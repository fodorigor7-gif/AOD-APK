package com.example.aodplayer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Несколько бесплатных источников без ключей. Если один недоступен
// (например, заблокирован у оператора) — пробуем следующий.
object Weather {

    private class Now(val temp: Int, val desc: String)
    private class Place(val lat: Double, val lon: Double, val name: String)

    fun cacheKey(ctx: Context): String =
        if (Prefs.autoLoc(ctx)) "auto" else Prefs.city(ctx)

    // Вызывать только из фонового потока!
    fun load(ctx: Context): String? {
        if (Prefs.autoLoc(ctx)) {
            val p = autoPlace(ctx) ?: return null
            val now = forecast(p.lat, p.lon) ?: return null
            return format(p.name, now)
        }
        val city = Prefs.city(ctx)
        if (city.isEmpty()) return null
        val p = geocode(city)
        if (p != null) {
            val now = forecast(p.lat, p.lon)
            if (now != null) return format(if (p.name.isNotEmpty()) p.name else city, now)
        }
        val now = safe { wttr(URLEncoder.encode(city, "UTF-8")) } ?: return null
        return format(city, now)
    }

    private fun format(name: String, now: Now): String {
        val sign = if (now.temp > 0) "+" else ""
        val parts = listOf(name, "$sign${now.temp}°", now.desc).filter { it.isNotBlank() }
        return parts.joinToString("  ")
    }

    private fun <T> safe(f: () -> T?): T? = try {
        f()
    } catch (e: Exception) {
        null
    }

    // ---------- где мы находимся ----------

    private fun autoPlace(ctx: Context): Place? {
        val loc = deviceLocation(ctx)
        if (loc != null) {
            val name = safe { reverseName(loc.latitude, loc.longitude) } ?: ""
            return Place(loc.latitude, loc.longitude, name)
        }
        // Нет доступа к GPS/сети — определяем по IP
        return safe { ipwho() } ?: safe { ipapi() }
    }

    private fun deviceLocation(ctx: Context): Location? {
        val ok = ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED ||
                ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        if (!ok) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            try {
                val l = lm.getLastKnownLocation(p)
                if (l != null && (best == null || l.time > best.time)) best = l
            } catch (e: Exception) {
            }
        }
        val b = best ?: return null
        if (System.currentTimeMillis() - b.time > 7 * 24 * 3600 * 1000L) return null
        return b
    }

    private fun ipwho(): Place? {
        val j = JSONObject(get("https://ipwho.is/"))
        if (!j.optBoolean("success", true)) return null
        val lat = j.optDouble("latitude", Double.NaN)
        val lon = j.optDouble("longitude", Double.NaN)
        if (lat.isNaN() || lon.isNaN()) return null
        return Place(lat, lon, j.optString("city", ""))
    }

    private fun ipapi(): Place? {
        val j = JSONObject(get("https://ipapi.co/json/"))
        val lat = j.optDouble("latitude", Double.NaN)
        val lon = j.optDouble("longitude", Double.NaN)
        if (lat.isNaN() || lon.isNaN()) return null
        return Place(lat, lon, j.optString("city", ""))
    }

    private fun reverseName(lat: Double, lon: Double): String {
        val j = JSONObject(
            get("https://nominatim.openstreetmap.org/reverse?format=json&zoom=10" +
                    "&accept-language=ru&lat=$lat&lon=$lon")
        )
        val a = j.optJSONObject("address") ?: return ""
        for (k in listOf("city", "town", "village", "municipality", "county")) {
            val v = a.optString(k, "")
            if (v.isNotEmpty()) return v
        }
        return ""
    }

    private fun geocode(city: String): Place? =
        safe { openMeteoGeo(city) } ?: safe { nominatimSearch(city) }

    private fun openMeteoGeo(city: String): Place? {
        val j = JSONObject(
            get("https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(city, "UTF-8") + "&count=1&language=ru")
        )
        val r = j.optJSONArray("results")?.optJSONObject(0) ?: return null
        return Place(r.getDouble("latitude"), r.getDouble("longitude"), r.optString("name", city))
    }

    private fun nominatimSearch(city: String): Place? {
        val arr = JSONArray(
            get("https://nominatim.openstreetmap.org/search?format=json&limit=1" +
                    "&accept-language=ru&q=" + URLEncoder.encode(city, "UTF-8"))
        )
        val r = arr.optJSONObject(0) ?: return null
        return Place(r.getString("lat").toDouble(), r.getString("lon").toDouble(), city)
    }

    // ---------- прогноз ----------

    private fun forecast(lat: Double, lon: Double): Now? =
        safe { openMeteo(lat, lon) } ?: safe { metNo(lat, lon) } ?: safe { wttr("$lat,$lon") }

    private fun openMeteo(lat: Double, lon: Double): Now? {
        val j = JSONObject(
            get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&timezone=auto")
        )
        val cur = j.getJSONObject("current")
        return Now(
            Math.round(cur.getDouble("temperature_2m")).toInt(),
            describeWmo(cur.getInt("weather_code"))
        )
    }

    private fun metNo(lat: Double, lon: Double): Now? {
        val j = JSONObject(
            get("https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=$lat&lon=$lon")
        )
        val first = j.getJSONObject("properties").getJSONArray("timeseries").getJSONObject(0)
        val data = first.getJSONObject("data")
        val t = data.getJSONObject("instant").getJSONObject("details").getDouble("air_temperature")
        val symbol = data.optJSONObject("next_1_hours")?.optJSONObject("summary")
            ?.optString("symbol_code", "")
            ?: data.optJSONObject("next_6_hours")?.optJSONObject("summary")
                ?.optString("symbol_code", "")
            ?: ""
        return Now(Math.round(t).toInt(), describeMet(symbol))
    }

    private fun wttr(query: String): Now? {
        val j = JSONObject(get("https://wttr.in/$query?format=j1&lang=ru"))
        val cur = j.getJSONArray("current_condition").getJSONObject(0)
        val t = Math.round(cur.getString("temp_C").toDouble()).toInt()
        val ru = cur.optJSONArray("lang_ru")?.optJSONObject(0)?.optString("value", "") ?: ""
        val en = cur.optJSONArray("weatherDesc")?.optJSONObject(0)?.optString("value", "") ?: ""
        return Now(t, (if (ru.isNotEmpty()) ru else en).lowercase())
    }

    // ---------- сеть ----------

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "AodPlayer/4.0 (personal Android app)")
        c.setRequestProperty("Accept", "application/json")
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun describeWmo(code: Int): String = when (code) {
        0 -> "ясно"
        1, 2 -> "малооблачно"
        3 -> "пасмурно"
        45, 48 -> "туман"
        in 51..57 -> "морось"
        in 61..67, in 80..82 -> "дождь"
        in 71..77, 85, 86 -> "снег"
        in 95..99 -> "гроза"
        else -> ""
    }

    private fun describeMet(symbol: String): String = when {
        symbol.contains("thunder") -> "гроза"
        symbol.contains("snow") || symbol.contains("sleet") -> "снег"
        symbol.contains("rain") || symbol.contains("drizzle") -> "дождь"
        symbol.contains("fog") -> "туман"
        symbol.contains("clearsky") -> "ясно"
        symbol.contains("fair") || symbol.contains("partlycloudy") -> "малооблачно"
        symbol.contains("cloudy") -> "пасмурно"
        else -> ""
    }
}
