package com.example.aodplayer

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

// Бесплатное API open-meteo.com, ключ не нужен
object Weather {
    fun fetch(city: String): String? {
        val geo = get(
            "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(city, "UTF-8") + "&count=1&language=ru"
        )
        val results = JSONObject(geo).optJSONArray("results") ?: return null
        val r = results.getJSONObject(0)
        val lat = r.getDouble("latitude")
        val lon = r.getDouble("longitude")
        val name = r.optString("name", city)
        val w = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&timezone=auto"
        )
        val cur = JSONObject(w).getJSONObject("current")
        val t = Math.round(cur.getDouble("temperature_2m")).toInt()
        val sign = if (t > 0) "+" else ""
        return "$name  $sign$t°  ${describe(cur.getInt("weather_code"))}".trim()
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "ясно"
        1, 2 -> "малооблачно"
        3 -> "пасмурно"
        45, 48 -> "туман"
        in 51..57 -> "морось"
        in 61..67, in 80..82 -> "дождь"
        in 71..77, 85, 86 -> "снег"
        in 95..99 -> "гроза"
        else -> ""
    }
}
