package com.example.aodplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

// Фон плеера: тёмный фон цвета альбома, обложка крупно с размытыми краями
// и затемнение по краям экрана
class CoverView(ctx: Context) : View(ctx) {

    private var bmp: Bitmap? = null
    private var bgColor = Color.BLACK

    var sizePct: Int = 100
        set(v) {
            field = v
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val maskPaint = Paint()
    private val vigPaint = Paint()

    init {
        maskPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    fun setCover(b: Bitmap?) {
        bmp = b
        bgColor = if (b != null) dominant(b) else Color.BLACK
        invalidate()
    }

    private fun dominant(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 8, 8, true)
        var r = 0L
        var g = 0L
        var bl = 0L
        for (x in 0 until 8) {
            for (y in 0 until 8) {
                val p = s.getPixel(x, y)
                r += Color.red(p)
                g += Color.green(p)
                bl += Color.blue(p)
            }
        }
        if (s !== b) s.recycle()
        val avg = Color.rgb((r / 64).toInt(), (g / 64).toInt(), (bl / 64).toInt())
        val hsv = FloatArray(3)
        Color.colorToHSV(avg, hsv)
        hsv[1] = minOf(1f, hsv[1] * 1.2f)
        hsv[2] = minOf(0.4f, hsv[2] * 0.45f)
        return Color.HSVToColor(hsv)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(bgColor)

        val b = bmp
        if (b != null && sizePct > 0) {
            val side = w * 0.98f * sizePct / 100f
            val cx = w / 2
            val cy = h * 0.42f
            val dst = RectF(cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2)

            val saved = c.saveLayer(dst, null)
            val sq = minOf(b.width, b.height)
            val src = Rect((b.width - sq) / 2, (b.height - sq) / 2,
                (b.width + sq) / 2, (b.height + sq) / 2)
            c.drawBitmap(b, src, dst, paint)

            // Края обложки плавно растворяются
            val f = side * 0.22f
            maskPaint.shader = LinearGradient(dst.left, 0f, dst.left + f, 0f,
                Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawRect(dst.left, dst.top, dst.left + f, dst.bottom, maskPaint)
            maskPaint.shader = LinearGradient(dst.right, 0f, dst.right - f, 0f,
                Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawRect(dst.right - f, dst.top, dst.right, dst.bottom, maskPaint)
            maskPaint.shader = LinearGradient(0f, dst.top, 0f, dst.top + f,
                Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawRect(dst.left, dst.top, dst.right, dst.top + f, maskPaint)
            maskPaint.shader = LinearGradient(0f, dst.bottom, 0f, dst.bottom - f,
                Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawRect(dst.left, dst.bottom - f, dst.right, dst.bottom, maskPaint)
            maskPaint.shader = null
            c.restoreToCount(saved)
        }

        // Тёмные границы экрана
        vigPaint.shader = RadialGradient(
            w / 2, h * 0.45f, maxOf(w, h) * 0.75f,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.BLACK),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, vigPaint)
    }
}
