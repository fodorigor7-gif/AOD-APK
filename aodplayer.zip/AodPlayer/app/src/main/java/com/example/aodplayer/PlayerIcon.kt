package com.example.aodplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

// Простые чёрно-белые кнопки плеера, нарисованные вручную (без эмодзи)
class PlayerIcon(context: Context, var type: Int) : View(context) {

    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(170, 170, 170)
        style = Paint.Style.FILL
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        path.reset()
        when (type) {
            PLAY -> {
                path.moveTo(w * 0.32f, h * 0.2f)
                path.lineTo(w * 0.32f, h * 0.8f)
                path.lineTo(w * 0.8f, h * 0.5f)
                path.close()
            }
            PAUSE -> {
                path.addRect(w * 0.27f, h * 0.2f, w * 0.42f, h * 0.8f, Path.Direction.CW)
                path.addRect(w * 0.58f, h * 0.2f, w * 0.73f, h * 0.8f, Path.Direction.CW)
            }
            NEXT -> {
                path.moveTo(w * 0.2f, h * 0.27f)
                path.lineTo(w * 0.2f, h * 0.73f)
                path.lineTo(w * 0.62f, h * 0.5f)
                path.close()
                path.addRect(w * 0.68f, h * 0.27f, w * 0.78f, h * 0.73f, Path.Direction.CW)
            }
            PREV -> {
                path.moveTo(w * 0.8f, h * 0.27f)
                path.lineTo(w * 0.8f, h * 0.73f)
                path.lineTo(w * 0.38f, h * 0.5f)
                path.close()
                path.addRect(w * 0.22f, h * 0.27f, w * 0.32f, h * 0.73f, Path.Direction.CW)
            }
        }
        canvas.drawPath(path, paint)
    }
}
