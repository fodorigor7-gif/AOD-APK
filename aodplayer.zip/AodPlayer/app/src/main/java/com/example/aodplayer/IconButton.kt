package com.example.aodplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

// Простые ч/б иконки плеера, нарисованные кодом (без эмодзи)
class IconButton(ctx: Context, kind: Int) : View(ctx) {
    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
    }

    var kind: Int = kind
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(170, 170, 170)
        style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) * 0.22f
        val cx = width / 2f
        val cy = height / 2f
        when (kind) {
            PLAY -> tri(c, cx - s * 0.7f, cy - s, cx - s * 0.7f, cy + s, cx + s, cy)
            PAUSE -> {
                c.drawRect(cx - s * 0.8f, cy - s, cx - s * 0.2f, cy + s, paint)
                c.drawRect(cx + s * 0.2f, cy - s, cx + s * 0.8f, cy + s, paint)
            }
            NEXT -> {
                tri(c, cx - s, cy - s, cx - s, cy + s, cx + s * 0.5f, cy)
                c.drawRect(cx + s * 0.6f, cy - s, cx + s, cy + s, paint)
            }
            PREV -> {
                tri(c, cx + s, cy - s, cx + s, cy + s, cx - s * 0.5f, cy)
                c.drawRect(cx - s, cy - s, cx - s * 0.6f, cy + s, paint)
            }
        }
    }

    private fun tri(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        p.lineTo(x3, y3)
        p.close()
        c.drawPath(p, paint)
    }
}
