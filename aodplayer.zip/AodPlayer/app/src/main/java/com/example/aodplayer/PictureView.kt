package com.example.aodplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import java.io.File

object PictureStore {
    fun file(ctx: Context): File = File(ctx.filesDir, "picture.png")
}

// Круглая картинка: края плавно растворяются, как на Huawei
class PictureView(ctx: Context, private val showPlaceholder: Boolean) : View(ctx) {

    private val bmp: Bitmap? = try {
        val f = PictureStore.file(ctx)
        if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    } catch (e: Exception) {
        null
    }
    private val sizePx = (220 * resources.displayMetrics.density).toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val maskPaint = Paint()
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        maskPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        hint.color = Color.rgb(90, 90, 90)
        hint.textAlign = Paint.Align.CENTER
        hint.textSize = 16 * resources.displayMetrics.scaledDensity
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (bmp == null && !showPlaceholder) setMeasuredDimension(1, 1)
        else setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val b = bmp
        if (b == null) {
            if (showPlaceholder) {
                hint.style = Paint.Style.STROKE
                hint.strokeWidth = 2f
                c.drawCircle(w / 2, h / 2, w / 2 - 4f, hint)
                hint.style = Paint.Style.FILL
                c.drawText("Фото", w / 2, h / 2 + hint.textSize / 3, hint)
            }
            return
        }
        val dst = RectF(0f, 0f, w, h)
        val saved = c.saveLayer(dst, null)
        c.drawBitmap(b, null, dst, paint)
        // Плавное исчезновение к краю круга
        maskPaint.shader = RadialGradient(
            w / 2, h / 2, w / 2,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.BLACK),
            floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(dst, maskPaint)
        maskPaint.shader = null
        c.restoreToCount(saved)
    }
}
