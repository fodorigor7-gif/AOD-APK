package com.example.aodplayer

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.KeyguardManager
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.CalendarContract
import android.service.notification.StatusBarNotification
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt
import kotlin.random.Random

class AodActivity : Activity() {

    private val GRAY = Color.rgb(170, 170, 170)
    private val DIM = Color.rgb(110, 110, 110)

    private val handler = Handler(Looper.getMainLooper())
    private var editMode = false
    private var fromLock = false

    // «экран» (в режиме редактирования он уменьшен и показан сверху)
    private lateinit var root: FrameLayout
    private lateinit var layer: FrameLayout
    private var outer: FrameLayout? = null
    private var viewScale = 1f

    // положение и размер каждого элемента
    private class Placement(var cx: Float, var cy: Float, var scale: Float)

    private val placements = HashMap<String, Placement>()
    private val wrappers = HashMap<String, FrameLayout>()
    private var artPct = 100
    private var selected: String? = null
    private var selLabel: TextView? = null

    // стиль плеера и фон-обложка
    private var playerStyle = 0
    private var coverView: CoverView? = null

    // яркость и датчики
    private var brAnim: ValueAnimator? = null
    private var curBr = 0.02f
    private var luxLevel = -1
    private var luxPending = -1
    private var luxCount = 0
    private var sensorMgr: SensorManager? = null

    // плеер
    private var artView: ImageView? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var playBtn: IconButton? = null
    private var controller: MediaController? = null
    private var lastTitle: String? = null
    private var lastBmp: Bitmap? = null
    private var msm: MediaSessionManager? = null
    private var listenerCn: ComponentName? = null

    // виджеты
    private var weatherView: TextView? = null
    private var calendarView: TextView? = null
    private var batteryView: BatteryView? = null
    private var notifBox: LinearLayout? = null
    private var batteryRegistered = false
    private var listeningNotifs = false

    // скрытый вход в настройки: 5 тапов по часам, потом удержание 3 сек
    private var taps = 0
    private var lastUp = 0L
    private var downAt = 0L
    private val holdRunnable = Runnable {
        taps = 0
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    // жест «смахнуть вверх» для разблокировки на экране блокировки
    private var swipeY = 0f
    private var swipeT = 0L

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { refreshController() }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = scheduleUi()
        override fun onPlaybackStateChanged(state: PlaybackState?) = scheduleUi()
    }

    private val applyRunnable = Runnable { applyUi() }

    private val shifter = object : Runnable {
        override fun run() {
            val d = resources.displayMetrics.density
            layer.translationX = Random.nextInt(-12, 13) * d
            layer.translationY = Random.nextInt(-20, 21) * d
            coverView?.translationX = layer.translationX
            coverView?.translationY = layer.translationY
            handler.postDelayed(this, 60_000)
        }
    }

    private val refreshTick = object : Runnable {
        override fun run() {
            loadWeather()
            loadCalendar()
            refreshNotifs()
            handler.postDelayed(this, 10 * 60 * 1000L)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            batteryView?.saver = pm.isPowerSaveMode
            if (i.action == Intent.ACTION_BATTERY_CHANGED) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL
                if (level >= 0) {
                    batteryView?.charging = charging
                    batteryView?.level = level * 100 / scale
                }
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        editMode = intent.getBooleanExtra("edit", false)
        fromLock = intent.getBooleanExtra("fromLock", false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (!editMode) setBrightnessPct(Prefs.brightness(this), false)

        artPct = Prefs.artPct(this)
        playerStyle = Prefs.playerStyle(this)
        buildUi()
        goFullscreen()

        // При самом первом запуске сразу показываем настройки
        if (!editMode && !Prefs.setupDone(this)) {
            Prefs.setSetupDone(this)
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        if (Prefs.enabled(this, Prefs.PLAYER)) startPlayer()
        if (Prefs.enabled(this, Prefs.BATTERY)) {
            val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            f.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            registerReceiver(batteryReceiver, f)
            batteryRegistered = true
        }
        if (Prefs.enabled(this, Prefs.NOTIFS)) {
            MediaListener.onChange = { handler.post { refreshNotifs() } }
            listeningNotifs = true
        }
        handler.post(refreshTick)
        if (!editMode && Prefs.shift(this)) handler.postDelayed(shifter, 60_000)

        if (!editMode && Prefs.autoOnLock(this)) {
            try {
                startForegroundService(Intent(this, AodService::class.java))
            } catch (e: Exception) {
            }
        }
        if (fromLock) wakeScreen()
    }

    // Приложение уже открыто, а AOD запросили снова (блокировка, кнопки громкости)
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        wakeScreen()
    }

    // После возврата из настроек перерисовываем экран с новыми параметрами
    override fun onRestart() {
        super.onRestart()
        if (!editMode) recreate()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "aodplayer:wake"
            )
            wl.acquire(3000)
        } catch (e: Exception) {
        }
    }

    // Смахнуть вверх — разблокировать телефон (если AOD открыт поверх экрана блокировки)
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!editMode) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    swipeY = ev.rawY
                    swipeT = ev.eventTime
                }
                MotionEvent.ACTION_UP -> {
                    val dy = swipeY - ev.rawY
                    val dt = ev.eventTime - swipeT
                    if (dy > resources.displayMetrics.heightPixels * 0.25f && dt < 700) tryUnlock()
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tryUnlock() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) return
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                finish()
            }
        })
    }

    // ---------- полный экран ----------

    @Suppress("DEPRECATION")
    private fun goFullscreen() {
        val w = window
        w.statusBarColor = Color.TRANSPARENT
        w.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false

        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false)
            val a = w.attributes
            a.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            w.attributes = a
            val c = w.insetsController
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            if (Build.VERSION.SDK_INT >= 28) {
                val a = w.attributes
                a.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                w.attributes = a
            }
            w.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    // ---------- построение экрана ----------

    private fun buildUi() {
        val d = resources.displayMetrics.density
        val size = realSize()
        val sw = size.first
        val sh = size.second

        root = FrameLayout(this)
        if (editMode) {
            // В режиме редактирования экран показан уменьшенным, сверху по центру
            val k = ((sh - 300 * d) / sh).coerceIn(0.4f, 0.65f)
            viewScale = k
            val bg = GradientDrawable()
            bg.setColor(Color.BLACK)
            bg.setStroke(maxOf(2, (3 / k).toInt()), Color.rgb(110, 110, 115))
            bg.cornerRadius = 32 * d / k
            root.background = bg
        } else {
            root.setBackgroundColor(Color.BLACK)
        }

        layer = FrameLayout(this)
        root.addView(layer, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        if (playerStyle == 2 && Prefs.enabled(this, Prefs.PLAYER)) {
            val cv = CoverView(this)
            cv.sizePct = artPct
            coverView = cv
            root.addView(cv, 0, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        for (id in Prefs.ALL) {
            if (!Prefs.enabled(this, id)) continue
            val v: View = when (id) {
                Prefs.PICTURE -> PictureView(this, editMode)
                Prefs.CLOCK -> buildClock()
                Prefs.NOTIFS -> buildNotifs()
                Prefs.PLAYER -> buildPlayer(d)
                Prefs.WEATHER -> buildWeather()
                Prefs.CALENDAR -> buildCalendar()
                Prefs.BATTERY -> buildBattery()
                else -> continue
            }
            val p = Placement(
                Prefs.posX(this, id), Prefs.posY(this, id), Prefs.scale(this, id) / 100f
            )
            placements[id] = p
            val w = wrap(id, v, p, d)
            layer.addView(w, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START))
            wrappers[id] = w
        }

        if (editMode) {
            val o = FrameLayout(this)
            o.setBackgroundColor(Color.BLACK)
            root.pivotX = sw / 2f
            root.pivotY = 0f
            root.scaleX = viewScale
            root.scaleY = viewScale
            root.translationY = 36 * d
            o.addView(root, FrameLayout.LayoutParams(sw, sh))
            outer = o
            buildEditBar(o, d)
            refreshOutlines()
            wrappers.keys.firstOrNull()?.let { select(it) }
            setContentView(o)
        } else {
            setupSecretGesture()
            setContentView(root)
        }
    }

    // Обёртка нужна, чтобы двигать и масштабировать элемент целиком
    private fun wrap(id: String, v: View, p: Placement, d: Float): FrameLayout {
        val w = object : FrameLayout(this@AodActivity) {
            override fun onInterceptTouchEvent(ev: MotionEvent): Boolean =
                editMode || id == Prefs.CLOCK
        }
        val pad = (8 * d).toInt()
        w.setPadding(pad, pad, pad, pad)
        w.addView(v, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        w.addOnLayoutChangeListener { view, _, _, _, _, _, _, _, _ -> applyPlacement(view, p) }
        if (editMode) enableDrag(w, p, id)
        return w
    }

    private fun applyPlacement(view: View, p: Placement) {
        val parent = view.parent as? View ?: return
        view.translationX = p.cx * parent.width - view.width / 2f
        view.translationY = p.cy * parent.height - view.height / 2f
        view.scaleX = p.scale
        view.scaleY = p.scale
    }

    private fun text(size: Float, color: Int): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(color)
        t.gravity = Gravity.CENTER_HORIZONTAL
        return t
    }

    private fun buildClock(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.textSize = 84f
        clock.setTextColor(GRAY)
        ClockStyle.apply(this, clock)
        clock.gravity = Gravity.CENTER_HORIZONTAL
        val date = TextClock(this)
        date.format24Hour = "EEEE, d MMMM"
        date.format12Hour = "EEEE, d MMMM"
        date.textSize = 16f
        date.setTextColor(DIM)
        date.gravity = Gravity.CENTER_HORIZONTAL
        box.addView(clock)
        box.addView(date)
        return box
    }

    private fun buildPlayer(d: Float): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL

        if (playerStyle == 0) {
            val a = ImageView(this)
            a.scaleType = ImageView.ScaleType.CENTER_CROP
            a.alpha = 0.55f
            artView = a
            box.addView(a, LinearLayout.LayoutParams((180 * d).toInt(), (180 * d).toInt()))
            applyArt()
        }

        val w = (300 * d).toInt()
        val t = text(18f, GRAY)
        t.setSingleLine()
        if (playerStyle == 2) t.setShadowLayer(14f, 0f, 0f, Color.BLACK)
        titleView = t
        val tlp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = (14 * d).toInt()
        box.addView(t, tlp)

        val ar = text(14f, DIM)
        ar.setSingleLine()
        if (playerStyle == 2) ar.setShadowLayer(14f, 0f, 0f, Color.BLACK)
        artistView = ar
        box.addView(ar, LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT))

        val controls = LinearLayout(this)
        controls.gravity = Gravity.CENTER
        val bs = (72 * d).toInt()

        // Кнопки видны и работают всегда: если плеер не открыт — шлём системную
        // команду «медиа-кнопка», она запускает последний плеер
        val prev = IconButton(this, IconButton.PREV)
        prev.setOnClickListener {
            val c = controller
            if (c != null) c.transportControls.skipToPrevious()
            else mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }
        val play = IconButton(this, IconButton.PLAY)
        play.setOnClickListener {
            val c = controller
            if (c != null) {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                else c.transportControls.play()
            } else {
                mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            }
        }
        val next = IconButton(this, IconButton.NEXT)
        next.setOnClickListener {
            val c = controller
            if (c != null) c.transportControls.skipToNext()
            else mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
        }
        playBtn = play

        controls.addView(prev, LinearLayout.LayoutParams(bs, bs))
        controls.addView(play, LinearLayout.LayoutParams(bs, bs))
        controls.addView(next, LinearLayout.LayoutParams(bs, bs))
        box.addView(controls)
        return box
    }

    private fun applyArt() {
        val a = artView ?: return
        val s = (180 * resources.displayMetrics.density * artPct / 100f).toInt()
        a.visibility = if (artPct == 0) View.GONE else View.VISIBLE
        val lp = a.layoutParams
        lp.width = s
        lp.height = s
        a.layoutParams = lp
    }

    private fun buildWeather(): View {
        val t = text(18f, GRAY)
        t.text = "Погода…"
        weatherView = t
        return t
    }

    private fun buildCalendar(): View {
        val t = text(16f, GRAY)
        t.text = "Календарь…"
        calendarView = t
        return t
    }

    private fun buildBattery(): View {
        val b = BatteryView(this)
        b.style = Prefs.batteryStyle(this)
        batteryView = b
        return b
    }

    private fun buildNotifs(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER
        notifBox = box
        refreshNotifs()
        return box
    }

    // ---------- значки уведомлений ----------

    private fun refreshNotifs() {
        val box = notifBox ?: return
        box.removeAllViews()
        val d = resources.displayMetrics.density
        val size = (28 * d).toInt()
        val margin = (6 * d).toInt()

        val svc = MediaListener.instance
        var list: Array<StatusBarNotification>? = null
        if (svc != null) {
            list = try {
                svc.activeNotifications
            } catch (e: Exception) {
                null
            }
        }

        var shown = 0
        if (list != null) {
            val seen = HashSet<String>()
            for (sbn in list) {
                if (shown >= 8) break
                if (sbn.packageName == packageName) continue
                if (Prefs.notifHideOngoing(this) && sbn.isOngoing) continue
                if (!seen.add(sbn.packageName)) continue
                val n: Notification = sbn.notification
                val icon = n.smallIcon ?: continue
                val dr = try {
                    icon.loadDrawable(this)
                } catch (e: Exception) {
                    null
                } ?: continue
                val tinted = dr.mutate()
                tinted.setTint(GRAY)
                val iv = ImageView(this)
                iv.setImageDrawable(tinted)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                val lp = LinearLayout.LayoutParams(size, size)
                lp.leftMargin = margin
                lp.rightMargin = margin
                box.addView(iv, lp)
                shown++
            }
        }
        // В режиме редактирования показываем заглушку, чтобы элемент можно было двигать
        if (shown == 0 && editMode) {
            val t = text(22f, Color.rgb(90, 90, 90))
            t.text = "• • •"
            box.addView(t)
        }
    }

    // ---------- скрытый вход в настройки ----------

    private fun setupSecretGesture() {
        // Если часы выключены, жест работает на всём экране — чтобы не потерять доступ
        val target: View = wrappers[Prefs.CLOCK] ?: root
        target.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downAt = e.eventTime
                    if (e.eventTime - lastUp > 2500) taps = 0
                    if (taps >= 5) handler.postDelayed(holdRunnable, 3000)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(holdRunnable)
                    if (e.actionMasked == MotionEvent.ACTION_UP && e.eventTime - downAt < 350) {
                        taps++
                        lastUp = e.eventTime
                    }
                }
            }
            true
        }
    }

    // ---------- режим редактирования ----------

    private fun enableDrag(w: View, p: Placement, id: String) {
        var sx = 0f
        var sy = 0f
        var scx = 0f
        var scy = 0f
        w.setOnTouchListener { v, e ->
            val parent = v.parent as View
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    select(id)
                    sx = e.rawX
                    sy = e.rawY
                    scx = p.cx
                    scy = p.cy
                }
                MotionEvent.ACTION_MOVE -> {
                    // экран показан уменьшенным, поэтому делим сдвиг пальца на масштаб
                    p.cx = (scx + (e.rawX - sx) / (parent.width * viewScale)).coerceIn(0f, 1f)
                    p.cy = (scy + (e.rawY - sy) / (parent.height * viewScale)).coerceIn(0f, 1f)
                    applyPlacement(v, p)
                }
            }
            true
        }
    }

    private fun select(id: String) {
        selected = id
        refreshOutlines()
        updateSelLabel()
    }

    private fun refreshOutlines() {
        val d = resources.displayMetrics.density
        for ((id, w) in wrappers) {
            val g = GradientDrawable()
            g.setColor(Color.TRANSPARENT)
            val sel = id == selected
            g.setStroke(
                maxOf(2, (2 * d / viewScale).toInt()),
                if (sel) Color.WHITE else Color.rgb(90, 90, 90),
                10f, 8f
            )
            w.background = g
        }
    }

    private fun updateSelLabel() {
        val id = selected
        val p = if (id != null) placements[id] else null
        selLabel?.text = if (id != null && p != null)
            "${Prefs.title(id)}: размер ${(p.scale * 100).roundToInt()}%"
        else "Нажми на элемент и тащи его"
    }

    private fun changeScale(delta: Float) {
        val id = selected ?: return
        val p = placements[id] ?: return
        p.scale = (((p.scale + delta) * 10).roundToInt() / 10f).coerceIn(0.3f, 4f)
        wrappers[id]?.let { applyPlacement(it, p) }
        updateSelLabel()
    }

    private fun changeArt(delta: Int) {
        artPct = (artPct + delta).coerceIn(0, 300)
        applyArt()
        coverView?.sizePct = artPct
    }

    // Точная подстройка стрелками (шаг около 0,4% экрана)
    private fun nudge(dx: Float, dy: Float) {
        val id = selected ?: return
        val p = placements[id] ?: return
        p.cx = (p.cx + dx).coerceIn(0f, 1f)
        p.cy = (p.cy + dy).coerceIn(0f, 1f)
        wrappers[id]?.let { applyPlacement(it, p) }
    }

    private fun resetAll() {
        for ((id, p) in placements) {
            p.cx = Prefs.defX(id)
            p.cy = Prefs.defY(id)
            p.scale = 1f
            wrappers[id]?.let { applyPlacement(it, p) }
        }
        artPct = 100
        applyArt()
        coverView?.sizePct = 100
        updateSelLabel()
    }

    private fun saveAll() {
        for ((id, p) in placements) {
            Prefs.setPlacement(this, id, p.cx, p.cy, (p.scale * 100).roundToInt())
        }
        Prefs.setArtPct(this, artPct)
        finish()
    }

    private fun smallBtn(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 13f
        b.minHeight = 0
        b.minimumHeight = dp(44)
        b.setPadding(dp(4), 0, dp(4), 0)
        b.setOnClickListener { onClick() }
        return b
    }

    // Стрелка с повтором при удержании
    private fun arrowBtn(t: String, dx: Float, dy: Float): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 18f
        b.minHeight = 0
        b.minimumHeight = dp(44)
        b.setPadding(dp(4), 0, dp(4), 0)
        val repeat = object : Runnable {
            override fun run() {
                nudge(dx, dy)
                handler.postDelayed(this, 60)
            }
        }
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    nudge(dx, dy)
                    handler.postDelayed(repeat, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(repeat)
                }
            }
            true
        }
        return b
    }

    private fun buildEditBar(container: FrameLayout, d: Float) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(Color.argb(240, 18, 18, 18))
        val pad = dp(8)
        box.setPadding(pad, pad, pad, dp(20))

        val label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.textSize = 15f
        label.setPadding(dp(4), 0, 0, dp(4))
        selLabel = label
        box.addView(label)

        fun row(vararg views: View): LinearLayout {
            val r = LinearLayout(this)
            for (v in views) {
                r.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            return r
        }

        val gap = { View(this) }

        box.addView(row(
            smallBtn("Размер −") { changeScale(-0.1f) },
            smallBtn("Размер +") { changeScale(0.1f) },
            smallBtn("Обложка −") { changeArt(-20) },
            smallBtn("Обложка +") { changeArt(20) }
        ))

        // Стрелки «как на клавиатуре»: сверху ↑, снизу ← ↓ →
        val step = 0.004f
        box.addView(row(gap(), arrowBtn("↑", 0f, -step), gap()))
        box.addView(row(
            arrowBtn("←", -step, 0f),
            arrowBtn("↓", 0f, step),
            arrowBtn("→", step, 0f)
        ))

        box.addView(row(
            smallBtn("Готово") { saveAll() },
            smallBtn("Сброс") { resetAll() },
            smallBtn("Отмена") { finish() }
        ))

        updateSelLabel()
        container.addView(box, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM))
    }

    // ---------- плеер ----------

    private fun startPlayer() {
        val m = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, MediaListener::class.java)
        msm = m
        listenerCn = cn
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
        } catch (e: SecurityException) {
            // нет доступа к уведомлениям
        }
        refreshController()
    }

    private fun pick(list: List<MediaController>): MediaController? {
        list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?.let { return it }
        val cur = controller
        if (cur != null && list.any { it.sessionToken == cur.sessionToken }) return cur
        return list.firstOrNull()
    }

    private fun refreshController() {
        val m = msm ?: return
        val cn = listenerCn ?: return
        val list: List<MediaController> = try {
            m.getActiveSessions(cn)
        } catch (e: SecurityException) {
            emptyList()
        }
        val picked = pick(list)
        val old = controller
        if (picked?.sessionToken != old?.sessionToken) {
            old?.unregisterCallback(controllerCallback)
            controller = picked
            picked?.registerCallback(controllerCallback)
        }
        scheduleUi()
    }

    private fun scheduleUi() {
        handler.removeCallbacks(applyRunnable)
        handler.postDelayed(applyRunnable, 150)
    }

    private fun setIfChanged(tv: TextView?, s: String) {
        if (tv != null && tv.text.toString() != s) tv.text = s
    }

    private fun applyUi() {
        val c = controller
        if (c == null) {
            setIfChanged(titleView, "Плеер не найден")
            setIfChanged(artistView, "Включи музыку и дай доступ к уведомлениям")
            showArt(null)
            lastBmp = null
            lastTitle = null
            playBtn?.kind = IconButton.PLAY
            return
        }
        val m = c.metadata
        val newTitle = m?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        if (!newTitle.isNullOrEmpty()) {
            val newArtist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
            setIfChanged(titleView, newTitle)
            setIfChanged(artistView, newArtist)
            val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            if (bmp != null) {
                if (bmp !== lastBmp) {
                    showArt(bmp)
                    lastBmp = bmp
                }
            } else if (newTitle != lastTitle) {
                showArt(null)
                lastBmp = null
            }
            lastTitle = newTitle
        }
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        playBtn?.kind = if (playing) IconButton.PAUSE else IconButton.PLAY
    }

    private fun showArt(b: Bitmap?) {
        if (playerStyle == 2) {
            coverView?.setCover(b)
        } else {
            val a = artView ?: return
            if (b != null) a.setImageBitmap(b) else a.setImageDrawable(null)
        }
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // ---------- яркость и датчики ----------

    private fun applyBr(v: Float) {
        curBr = v
        val lp = window.attributes
        lp.screenBrightness = v
        window.attributes = lp
    }

    private fun setBrightnessPct(pct: Int, animate: Boolean) {
        val target = pct.coerceIn(1, 100) / 100f
        brAnim?.cancel()
        if (!animate) {
            applyBr(target)
            return
        }
        val a = ValueAnimator.ofFloat(curBr, target)
        a.duration = 600
        a.addUpdateListener { applyBr(it.animatedValue as Float) }
        brAnim = a
        a.start()
    }

    private val lightListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val lux = e.values[0]
            val lvl = if (lux < Prefs.luxLow(this@AodActivity)) 0
            else if (lux < Prefs.luxHigh(this@AodActivity)) 1 else 2
            if (lvl == luxLevel) {
                luxPending = -1
                return
            }
            if (lvl == luxPending) luxCount++ else {
                luxPending = lvl
                luxCount = 1
            }
            // меняем уровень только если он держится несколько замеров подряд
            if (luxLevel == -1 || luxCount >= 5) {
                val first = luxLevel == -1
                luxLevel = lvl
                luxPending = -1
                val pct = when (lvl) {
                    0 -> Prefs.brDark(this@AodActivity)
                    1 -> Prefs.brMid(this@AodActivity)
                    else -> Prefs.brBright(this@AodActivity)
                }
                setBrightnessPct(pct, !first)
            }
        }

        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }

    private val proxListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val near = e.values[0] < minOf(e.sensor.maximumRange, 5f)
            setBlackout(near)
        }

        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }

    private fun setBlackout(on: Boolean) {
        val vis = if (on) View.INVISIBLE else View.VISIBLE
        layer.visibility = vis
        coverView?.visibility = vis
    }

    private fun registerSensors() {
        if (editMode) return
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorMgr = sm
        if (Prefs.autoBright(this)) {
            val s = sm.getDefaultSensor(Sensor.TYPE_LIGHT)
            if (s != null) {
                luxLevel = -1
                luxPending = -1
                sm.registerListener(lightListener, s, SensorManager.SENSOR_DELAY_NORMAL)
            }
        }
        if (Prefs.proximity(this)) {
            val s = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY)
            if (s != null) sm.registerListener(proxListener, s, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    private fun unregisterSensors() {
        val sm = sensorMgr ?: return
        sm.unregisterListener(lightListener)
        sm.unregisterListener(proxListener)
        setBlackout(false)
    }

    override fun onResume() {
        super.onResume()
        registerSensors()
    }

    override fun onPause() {
        super.onPause()
        unregisterSensors()
    }

    // ---------- погода ----------

    private fun loadWeather() {
        val v = weatherView ?: return
        val key = Weather.cacheKey(this)
        if (key.isEmpty()) {
            v.text = "Укажи город в настройках"
            return
        }
        val cached = Prefs.weatherText(this)
        val same = Prefs.weatherCity(this) == key
        if (cached.isNotEmpty() && same) v.text = cached
        val fresh = cached.isNotEmpty() && same &&
                System.currentTimeMillis() - Prefs.weatherTime(this) < 25 * 60 * 1000L
        if (fresh) return
        Thread {
            val r = try {
                Weather.load(applicationContext)
            } catch (e: Exception) {
                null
            }
            if (r != null) {
                Prefs.setWeather(this, key, r)
                runOnUiThread { weatherView?.text = r }
            } else if (cached.isEmpty() || !same) {
                runOnUiThread { weatherView?.text = "Погода недоступна" }
            }
        }.start()
    }

    // ---------- календарь ----------

    private fun loadCalendar() {
        val v = calendarView ?: return
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            v.text = "Нет доступа к календарю (дай в настройках)"
            return
        }
        val now = System.currentTimeMillis()
        val end = now + 3 * 24 * 3600 * 1000L
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, now)
        ContentUris.appendId(b, end)
        val sb = StringBuilder()
        var n = 0
        try {
            val cur = contentResolver.query(
                b.build(),
                arrayOf(
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.ALL_DAY
                ),
                null, null, CalendarContract.Instances.BEGIN + " ASC"
            )
            cur?.use {
                val timed = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())
                val allDay = SimpleDateFormat("d MMM", Locale.getDefault())
                allDay.timeZone = TimeZone.getTimeZone("UTC")
                while (it.moveToNext() && n < 3) {
                    val title = it.getString(0) ?: "Без названия"
                    val begin = it.getLong(1)
                    val whole = it.getInt(2) == 1
                    val whenText =
                        if (whole) allDay.format(Date(begin)) else timed.format(Date(begin))
                    sb.append(whenText).append("  ").append(title).append('\n')
                    n++
                }
            }
        } catch (e: Exception) {
            v.text = "Календарь недоступен"
            return
        }
        v.text = if (n == 0) "Событий нет" else sb.toString().trim()
    }

    override fun onDestroy() {
        handler.removeCallbacks(shifter)
        handler.removeCallbacks(refreshTick)
        handler.removeCallbacks(applyRunnable)
        handler.removeCallbacks(holdRunnable)
        brAnim?.cancel()
        if (listeningNotifs) MediaListener.onChange = null
        controller?.unregisterCallback(controllerCallback)
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        if (batteryRegistered) unregisterReceiver(batteryReceiver)
        super.onDestroy()
    }
}
