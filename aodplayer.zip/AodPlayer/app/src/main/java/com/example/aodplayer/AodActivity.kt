package com.example.aodplayer

import android.app.Activity
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import kotlin.random.Random

class AodActivity : Activity() {

    private val GRAY = Color.rgb(170, 170, 170)
    private val DIM = Color.rgb(110, 110, 110)

    private lateinit var content: LinearLayout
    private lateinit var art: ImageView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var playBtn: TextView

    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var msm: MediaSessionManager
    private lateinit var listenerCn: ComponentName

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { refreshController() }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = updateUi()
        override fun onPlaybackStateChanged(state: PlaybackState?) = updateUi()
    }

    // Сдвиг картинки раз в минуту — защита OLED от выгорания
    private val shifter = object : Runnable {
        override fun run() {
            val d = resources.displayMetrics.density
            content.translationX = Random.nextInt(-24, 25) * d
            content.translationY = Random.nextInt(-40, 41) * d
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Минимальная яркость
        val lp = window.attributes
        lp.screenBrightness = 0.01f
        window.attributes = lp

        buildUi()
        hideSystemBars()

        msm = getSystemService(MediaSessionManager::class.java)
        listenerCn = ComponentName(this, MediaListener::class.java)
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerCn)
        } catch (e: SecurityException) { /* нет доступа к уведомлениям */ }
        refreshController()
        handler.postDelayed(shifter, 60_000)
    }

    private fun buildUi() {
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 84f
            setTextColor(GRAY)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        val date = TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"
            format12Hour = "EEEE, d MMMM"
            textSize = 16f
            setTextColor(DIM)
            gravity = Gravity.CENTER
        }
        art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.55f
            visibility = View.GONE
        }
        title = TextView(this).apply {
            textSize = 18f
            setTextColor(GRAY)
            gravity = Gravity.CENTER
            maxLines = 1
        }
        artist = TextView(this).apply {
            textSize = 14f
            setTextColor(DIM)
            gravity = Gravity.CENTER
            maxLines = 1
        }
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
        }
        fun btn(txt: String, action: () -> Unit) = TextView(this).apply {
            text = txt
            textSize = 34f
            setTextColor(GRAY)
            setPadding((22 * d).toInt(), (10 * d).toInt(), (22 * d).toInt(), (10 * d).toInt())
            setOnClickListener { action() }
        }
        playBtn = btn("▶") {
            val c = controller ?: return@btn
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
            else c.transportControls.play()
        }
        controls.addView(btn("⏮") { controller?.transportControls?.skipToPrevious() })
        controls.addView(playBtn)
        controls.addView(btn("⏭") { controller?.transportControls?.skipToNext() })

        content.addView(clock)
        content.addView(date)
        content.addView(art, LinearLayout.LayoutParams((200 * d).toInt(), (200 * d).toInt()).apply {
            topMargin = (36 * d).toInt()
        })
        content.addView(title, LinearLayout.LayoutParams(
            (300 * d).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (16 * d).toInt() })
        content.addView(artist, LinearLayout.LayoutParams(
            (300 * d).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT))
        content.addView(controls)
        root.addView(content)
        setContentView(root)
    }

    private fun refreshController() {
        controller?.unregisterCallback(controllerCallback)
        controller = try {
            msm.getActiveSessions(listenerCn).firstOrNull()
        } catch (e: SecurityException) {
            null
        }
        controller?.registerCallback(controllerCallback)
        updateUi()
    }

    private fun updateUi() {
        val c = controller
        if (c == null) {
            title.text = "Плеер не найден"
            artist.text = "Включи музыку и дай доступ к уведомлениям"
            art.visibility = View.GONE
            playBtn.text = "▶"
            return
        }
        val m = c.metadata
        title.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        artist.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (bmp != null) {
            art.setImageBitmap(bmp)
            art.visibility = View.VISIBLE
        } else {
            art.visibility = View.GONE
        }
        playBtn.text = if (c.playbackState?.state == PlaybackState.STATE_PLAYING) "⏸" else "▶"
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(shifter)
        controller?.unregisterCallback(controllerCallback)
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) {}
        super.onDestroy()
    }
}
