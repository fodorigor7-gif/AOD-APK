package com.example.aodplayer

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random

class AodActivity : Activity() {

    private val GRAY = Color.rgb(170, 170, 170)
    private val DIM = Color.rgb(110, 110, 110)

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var content: LinearLayout

    // плеер
    private var artView: ImageView? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var playBtn: IconButton? = null
    private var controller: MediaController? = null
    private var lastTitle: String? = null
    private var lastBmp: Bitmap? = null
    private var msm: MediaSessionManager? = null
    private var listenerCn: ComponentName? = null

    // виджеты
    private var weatherView: TextView? = null
    private var calendarView: TextView? = null
    private var batteryView: TextView? = null
    private var batteryRegistered = false

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { refreshController() }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = scheduleUi()
        override fun onPlaybackStateChanged(state: PlaybackState?) = scheduleUi()
    }

    // Обновляем интерфейс не сразу, а с небольшой паузой: плеер шлёт кучу событий
    // подряд при переключении трека — раньше из-за этого всё мерцало
    private val applyRunnable = Runnable { applyUi() }

    private val shifter = object : Runnable {
        override fun run() {
            val d = resources.displayMetrics.density
            content.translationX = Random.nextInt(-20, 21) * d
            content.translationY = Random.nextInt(-30, 31) * d
            handler.postDelayed(this, 60_000)
        }
    }

    private val refreshTick = object : Runnable {
        override fun run() {
            loadWeather()
            loadCalendar()
            handler.postDelayed(this, 10 * 60 * 1000L)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0) {
                batteryView?.text =
                    "Батарея ${level * 100 / scale}%" + if (charging) " · заряжается" else ""
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val lp = window.attributes
        lp.screenBrightness = Prefs.brightness(this) / 100f
        window.attributes = lp

        buildUi()
        hideSystemBars()

        if (Prefs.enabled(this, Prefs.PLAYER)) startPlayer()
        if (Prefs.enabled(this, Prefs.BATTERY)) {
            registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            batteryRegistered = true
        }
        handler.post(refreshTick)
        if (Prefs.shift(this)) handler.postDelayed(shifter, 60_000)
    }

    // ---------- построение экрана ----------

    private fun buildUi() {
        val d = resources.displayMetrics.density
        val hg = when (Prefs.hAlign(this)) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        val vg = when (Prefs.vAlign(this)) {
            0 -> Gravity.TOP
            2 -> Gravity.BOTTOM
            else -> Gravity.CENTER_VERTICAL
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.setOnClickListener { finish() }

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.gravity = hg
        val px = (32 * d).toInt()
        val py = (48 * d).toInt()
        content.setPadding(px, py, px, py)

        for (id in Prefs.order(this)) {
            if (!Prefs.enabled(this, id)) continue
            val v: View = when (id) {
                Prefs.CLOCK -> buildClock(hg)
                Prefs.PLAYER -> buildPlayer(hg, d)
                Prefs.WEATHER -> buildWeather(hg)
                Prefs.CALENDAR -> buildCalendar(hg)
                Prefs.BATTERY -> buildBattery(hg)
                else -> continue
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = (28 * d).toInt()
            content.addView(v, lp)
        }

        root.addView(
            content,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, vg
            )
        )
        setContentView(root)
    }

    private fun text(size: Float, color: Int, hg: Int): TextView {
        val t = TextView(this)
        t.textSize = size
        t.setTextColor(color)
        t.gravity = hg
        return t
    }

    private fun buildClock(hg: Int): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = hg
        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.textSize = Prefs.clockSize(this).toFloat()
        clock.setTextColor(GRAY)
        clock.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        clock.gravity = hg
        val date = TextClock(this)
        date.format24Hour = "EEEE, d MMMM"
        date.format12Hour = "EEEE, d MMMM"
        date.textSize = 16f
        date.setTextColor(DIM)
        date.gravity = hg
        box.addView(clock)
        box.addView(date)
        return box
    }

    private fun buildPlayer(hg: Int, d: Float): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = hg

        // Место под обложку занято всегда — поэтому ничего не прыгает
        val artSize = (180 * d).toInt()
        val a = ImageView(this)
        a.scaleType = ImageView.ScaleType.CENTER_CROP
        a.alpha = 0.55f
        artView = a
        box.addView(a, LinearLayout.LayoutParams(artSize, artSize))

        val w = (300 * d).toInt()
        val t = text(18f, GRAY, hg)
        t.maxLines = 1
        t.setSingleLine()
        titleView = t
        val tlp = LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = (14 * d).toInt()
        box.addView(t, tlp)

        val ar = text(14f, DIM, hg)
        ar.setSingleLine()
        artistView = ar
        box.addView(ar, LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT))

        val controls = LinearLayout(this)
        controls.gravity = Gravity.CENTER
        val bs = (72 * d).toInt()

        val prev = IconButton(this, IconButton.PREV)
        prev.setOnClickListener { controller?.transportControls?.skipToPrevious() }
        val play = IconButton(this, IconButton.PLAY)
        play.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
            else c.transportControls.play()
        }
        val next = IconButton(this, IconButton.NEXT)
        next.setOnClickListener { controller?.transportControls?.skipToNext() }
        playBtn = play

        controls.addView(prev, LinearLayout.LayoutParams(bs, bs))
        controls.addView(play, LinearLayout.LayoutParams(bs, bs))
        controls.addView(next, LinearLayout.LayoutParams(bs, bs))
        box.addView(controls)
        return box
    }

    private fun buildWeather(hg: Int): View {
        val t = text(18f, GRAY, hg)
        t.text = "Погода…"
        weatherView = t
        return t
    }

    private fun buildCalendar(hg: Int): View {
        val t = text(16f, GRAY, hg)
        t.text = "Календарь…"
        calendarView = t
        return t
    }

    private fun buildBattery(hg: Int): View {
        val t = text(16f, DIM, hg)
        batteryView = t
        return t
    }

    // ---------- плеер ----------

    private fun startPlayer() {
        val m = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, MediaListener::class.java)
        msm = m
        listenerCn = cn
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
        } catch (e: SecurityException) {
            // нет доступа к уведомлениям
        }
        refreshController()
    }

    private fun pick(list: List<MediaController>): MediaController? {
        list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?.let { return it }
        val cur = controller
        if (cur != null && list.any { it.sessionToken == cur.sessionToken }) return cur
        return list.firstOrNull()
    }

    private fun refreshController() {
        val m = msm ?: return
        val cn = listenerCn ?: return
        val list: List<MediaController> = try {
            m.getActiveSessions(cn)
        } catch (e: SecurityException) {
            emptyList()
        }
        val picked = pick(list)
        val old = controller
        if (picked?.sessionToken != old?.sessionToken) {
            old?.unregisterCallback(controllerCallback)
            controller = picked
            picked?.registerCallback(controllerCallback)
        }
        scheduleUi()
    }

    private fun scheduleUi() {
        handler.removeCallbacks(applyRunnable)
        handler.postDelayed(applyRunnable, 150)
    }

    private fun setIfChanged(tv: TextView?, s: String) {
        if (tv != null && tv.text.toString() != s) tv.text = s
    }

    private fun applyUi() {
        val c = controller
        if (c == null) {
            setIfChanged(titleView, "Плеер не найден")
            setIfChanged(artistView, "Включи музыку и дай доступ к уведомлениям")
            artView?.setImageDrawable(null)
            lastBmp = null
            lastTitle = null
            playBtn?.kind = IconButton.PLAY
            return
        }
        val m = c.metadata
        val newTitle = m?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        // Если метаданные на миг пустые (между треками) — оставляем прежнее, не мигаем
        if (!newTitle.isNullOrEmpty()) {
            val newArtist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: m?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
            setIfChanged(titleView, newTitle)
            setIfChanged(artistView, newArtist)
            val bmp = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            if (bmp != null) {
                if (bmp !== lastBmp) {
                    artView?.setImageBitmap(bmp)
                    lastBmp = bmp
                }
            } else if (newTitle != lastTitle) {
                artView?.setImageDrawable(null)
                lastBmp = null
            }
            lastTitle = newTitle
        }
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        playBtn?.kind = if (playing) IconButton.PAUSE else IconButton.PLAY
    }

    // ---------- погода ----------

    private fun loadWeather() {
        val v = weatherView ?: return
        val city = Prefs.city(this)
        if (city.isEmpty()) {
            v.text = "Укажи город в настройках"
            return
        }
        val cached = Prefs.weatherText(this)
        val sameCity = Prefs.weatherCity(this) == city
        if (cached.isNotEmpty() && sameCity) v.text = cached
        val fresh = cached.isNotEmpty() && sameCity &&
                System.currentTimeMillis() - Prefs.weatherTime(this) < 25 * 60 * 1000L
        if (fresh) return
        Thread {
            val r = try {
                Weather.fetch(city)
            } catch (e: Exception) {
                null
            }
            if (r != null) {
                Prefs.setWeather(this, city, r)
                runOnUiThread { weatherView?.text = r }
            } else if (cached.isEmpty() || !sameCity) {
                runOnUiThread { weatherView?.text = "Погода недоступна" }
            }
        }.start()
    }

    // ---------- календарь ----------

    private fun loadCalendar() {
        val v = calendarView ?: return
        if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            v.text = "Нет доступа к календарю (дай в настройках)"
            return
        }
        val now = System.currentTimeMillis()
        val end = now + 3 * 24 * 3600 * 1000L
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, now)
        ContentUris.appendId(b, end)
        val sb = StringBuilder()
        var n = 0
        try {
            val cur = contentResolver.query(
                b.build(),
                arrayOf(
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.ALL_DAY
                ),
                null, null, CalendarContract.Instances.BEGIN + " ASC"
            )
            cur?.use {
                val timed = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())
                val allDay = SimpleDateFormat("d MMM", Locale.getDefault())
                allDay.timeZone = TimeZone.getTimeZone("UTC")
                while (it.moveToNext() && n < 3) {
                    val title = it.getString(0) ?: "Без названия"
                    val begin = it.getLong(1)
                    val whole = it.getInt(2) == 1
                    val whenText =
                        if (whole) allDay.format(Date(begin)) else timed.format(Date(begin))
                    sb.append(whenText).append("  ").append(title).append('\n')
                    n++
                }
            }
        } catch (e: Exception) {
            v.text = "Календарь недоступен"
            return
        }
        v.text = if (n == 0) "Событий нет" else sb.toString().trim()
    }

    // ---------- прочее ----------

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(shifter)
        handler.removeCallbacks(refreshTick)
        handler.removeCallbacks(applyRunnable)
        controller?.unregisterCallback(controllerCallback)
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        if (batteryRegistered) unregisterReceiver(batteryReceiver)
        super.onDestroy()
    }
}
