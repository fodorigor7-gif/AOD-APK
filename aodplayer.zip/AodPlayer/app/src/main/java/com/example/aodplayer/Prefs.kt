package com.example.aodplayer

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val PICTURE = "picture"
    const val CLOCK = "clock"
    const val NOTIFS = "notifs"
    const val PLAYER = "player"
    const val WEATHER = "weather"
    const val CALENDAR = "calendar"
    const val BATTERY = "battery"

    // Порядок = порядок слоёв: картинка сзади, батарея спереди
    val ALL = listOf(PICTURE, CLOCK, NOTIFS, PLAYER, WEATHER, CALENDAR, BATTERY)

    fun title(id: String): String = when (id) {
        PICTURE -> "Картинка"
        CLOCK -> "Часы"
        NOTIFS -> "Значки уведомлений"
        PLAYER -> "Плеер"
        WEATHER -> "Погода"
        CALENDAR -> "Календарь"
        BATTERY -> "Батарея"
        else -> id
    }

    // Положение по умолчанию: центр элемента в долях экрана (0..1)
    fun defX(id: String): Float = 0.5f
    fun defY(id: String): Float = when (id) {
        PICTURE -> 0.45f
        CLOCK -> 0.25f
        NOTIFS -> 0.37f
        PLAYER -> 0.55f
        WEATHER -> 0.78f
        CALENDAR -> 0.86f
        BATTERY -> 0.07f
        else -> 0.5f
    }

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("aod", Context.MODE_PRIVATE)

    fun enabled(c: Context, id: String): Boolean =
        sp(c).getBoolean("en_$id", id == CLOCK || id == PLAYER || id == NOTIFS)
    fun setEnabled(c: Context, id: String, v: Boolean) =
        sp(c).edit().putBoolean("en_$id", v).apply()

    fun posX(c: Context, id: String): Float = sp(c).getFloat("px_$id", defX(id))
    fun posY(c: Context, id: String): Float = sp(c).getFloat("py_$id", defY(id))
    fun scale(c: Context, id: String): Int = sp(c).getInt("sc_$id", 100)
    fun setPlacement(c: Context, id: String, x: Float, y: Float, scalePct: Int) =
        sp(c).edit().putFloat("px_$id", x).putFloat("py_$id", y).putInt("sc_$id", scalePct).apply()

    fun resetPlacement(c: Context) {
        val e = sp(c).edit()
        for (id in ALL) e.remove("px_$id").remove("py_$id").remove("sc_$id")
        e.remove("art_pct")
        e.apply()
    }

    fun artPct(c: Context): Int = sp(c).getInt("art_pct", 100)
    fun setArtPct(c: Context, v: Int) = sp(c).edit().putInt("art_pct", v).apply()

    // 0 = обычный, 1 = без обложки, 2 = обложка на весь экран
    fun playerStyle(c: Context): Int = sp(c).getInt("player_style", 0)
    fun setPlayerStyle(c: Context, v: Int) = sp(c).edit().putInt("player_style", v).apply()

    // Часы: толщина 100..900, расстояние между цифрами в сотых долях em (-10..60)
    fun clockWeight(c: Context): Int = sp(c).getInt("clock_weight", 100)
    fun setClockWeight(c: Context, v: Int) = sp(c).edit().putInt("clock_weight", v).apply()
    fun clockSpacing(c: Context): Int = sp(c).getInt("clock_spacing", 0)
    fun setClockSpacing(c: Context, v: Int) = sp(c).edit().putInt("clock_spacing", v).apply()

    // Батарея: 0 = только иконка, 1 = число внутри иконки, 2 = «89%» и иконка справа
    fun batteryStyle(c: Context): Int = sp(c).getInt("battery_style", 2)
    fun setBatteryStyle(c: Context, v: Int) = sp(c).edit().putInt("battery_style", v).apply()

    // Значки уведомлений
    fun notifHideOngoing(c: Context): Boolean = sp(c).getBoolean("notif_hide_ongoing", true)
    fun setNotifHideOngoing(c: Context, v: Boolean) =
        sp(c).edit().putBoolean("notif_hide_ongoing", v).apply()

    // Яркость
    fun brightness(c: Context): Int = sp(c).getInt("brightness", 3)
    fun setBrightness(c: Context, v: Int) = sp(c).edit().putInt("brightness", v).apply()
    fun autoBright(c: Context): Boolean = sp(c).getBoolean("auto_bright", false)
    fun setAutoBright(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_bright", v).apply()
    fun brDark(c: Context): Int = sp(c).getInt("br_dark", 3)
    fun setBrDark(c: Context, v: Int) = sp(c).edit().putInt("br_dark", v).apply()
    fun brMid(c: Context): Int = sp(c).getInt("br_mid", 15)
    fun setBrMid(c: Context, v: Int) = sp(c).edit().putInt("br_mid", v).apply()
    fun brBright(c: Context): Int = sp(c).getInt("br_bright", 50)
    fun setBrBright(c: Context, v: Int) = sp(c).edit().putInt("br_bright", v).apply()
    fun luxLow(c: Context): Int = sp(c).getInt("lux_low", 20)
    fun setLuxLow(c: Context, v: Int) = sp(c).edit().putInt("lux_low", v).apply()
    fun luxHigh(c: Context): Int = sp(c).getInt("lux_high", 2000)
    fun setLuxHigh(c: Context, v: Int) = sp(c).edit().putInt("lux_high", v).apply()

    // Датчик приближения
    fun proximity(c: Context): Boolean = sp(c).getBoolean("proximity", false)
    fun setProximity(c: Context, v: Boolean) = sp(c).edit().putBoolean("proximity", v).apply()

    // Блокировка и запуск
    fun autoOnLock(c: Context): Boolean = sp(c).getBoolean("auto_on_lock", false)
    fun setAutoOnLock(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_on_lock", v).apply()
    fun volLaunch(c: Context): Boolean = sp(c).getBoolean("vol_launch", true)
    fun setVolLaunch(c: Context, v: Boolean) = sp(c).edit().putBoolean("vol_launch", v).apply()

    fun shift(c: Context): Boolean = sp(c).getBoolean("shift", true)
    fun setShift(c: Context, v: Boolean) = sp(c).edit().putBoolean("shift", v).apply()

    fun setupDone(c: Context): Boolean = sp(c).getBoolean("setup_done", false)
    fun setSetupDone(c: Context) = sp(c).edit().putBoolean("setup_done", true).apply()

    // Погода
    fun autoLoc(c: Context): Boolean = sp(c).getBoolean("auto_loc", true)
    fun setAutoLoc(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_loc", v).apply()
    fun city(c: Context): String = sp(c).getString("city", "")!!
    fun setCity(c: Context, v: String) = sp(c).edit().putString("city", v).apply()

    fun weatherText(c: Context): String = sp(c).getString("w_text", "")!!
    fun weatherCity(c: Context): String = sp(c).getString("w_city", "")!!
    fun weatherTime(c: Context): Long = sp(c).getLong("w_time", 0L)
    fun setWeather(c: Context, key: String, text: String) =
        sp(c).edit().putString("w_city", key).putString("w_text", text)
            .putLong("w_time", System.currentTimeMillis()).apply()
}
