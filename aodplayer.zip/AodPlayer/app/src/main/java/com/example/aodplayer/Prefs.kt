package com.example.aodplayer

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val CLOCK = "clock"
    const val PLAYER = "player"
    const val WEATHER = "weather"
    const val CALENDAR = "calendar"
    const val BATTERY = "battery"
    val ALL = listOf(CLOCK, PLAYER, WEATHER, CALENDAR, BATTERY)

    fun title(id: String): String = when (id) {
        CLOCK -> "Часы"
        PLAYER -> "Плеер"
        WEATHER -> "Погода"
        CALENDAR -> "Календарь"
        BATTERY -> "Батарея"
        else -> id
    }

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("aod", Context.MODE_PRIVATE)

    fun order(c: Context): MutableList<String> {
        val saved = sp(c).getString("order", "")!!
            .split(",").filter { it in ALL }.distinct().toMutableList()
        for (id in ALL) if (id !in saved) saved.add(id)
        return saved
    }
    fun setOrder(c: Context, list: List<String>) =
        sp(c).edit().putString("order", list.joinToString(",")).apply()

    fun enabled(c: Context, id: String): Boolean =
        sp(c).getBoolean("en_$id", id == CLOCK || id == PLAYER)
    fun setEnabled(c: Context, id: String, v: Boolean) =
        sp(c).edit().putBoolean("en_$id", v).apply()

    fun brightness(c: Context): Int = sp(c).getInt("brightness", 1)
    fun setBrightness(c: Context, v: Int) = sp(c).edit().putInt("brightness", v).apply()

    fun clockSize(c: Context): Int = sp(c).getInt("clock_size", 84)
    fun setClockSize(c: Context, v: Int) = sp(c).edit().putInt("clock_size", v).apply()

    // 0 = сверху, 1 = по центру, 2 = снизу
    fun vAlign(c: Context): Int = sp(c).getInt("v_align", 1)
    fun setVAlign(c: Context, v: Int) = sp(c).edit().putInt("v_align", v).apply()

    // 0 = слева, 1 = по центру, 2 = справа
    fun hAlign(c: Context): Int = sp(c).getInt("h_align", 1)
    fun setHAlign(c: Context, v: Int) = sp(c).edit().putInt("h_align", v).apply()

    fun shift(c: Context): Boolean = sp(c).getBoolean("shift", true)
    fun setShift(c: Context, v: Boolean) = sp(c).edit().putBoolean("shift", v).apply()

    fun city(c: Context): String = sp(c).getString("city", "")!!
    fun setCity(c: Context, v: String) = sp(c).edit().putString("city", v).apply()

    fun weatherText(c: Context): String = sp(c).getString("w_text", "")!!
    fun weatherCity(c: Context): String = sp(c).getString("w_city", "")!!
    fun weatherTime(c: Context): Long = sp(c).getLong("w_time", 0L)
    fun setWeather(c: Context, city: String, text: String) =
        sp(c).edit().putString("w_city", city).putString("w_text", text)
            .putLong("w_time", System.currentTimeMillis()).apply()
}
