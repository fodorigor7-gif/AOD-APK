package com.example.aodplayer

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val CLOCK = "clock"
    const val PLAYER = "player"
    const val WEATHER = "weather"
    const val CALENDAR = "calendar"
    const val BATTERY = "battery"
    val ALL = listOf(CLOCK, PLAYER, WEATHER, CALENDAR, BATTERY)

    fun title(id: String): String = when (id) {
        CLOCK -> "Часы"
        PLAYER -> "Плеер"
        WEATHER -> "Погода"
        CALENDAR -> "Календарь"
        BATTERY -> "Батарея"
        else -> id
    }

    // Положение по умолчанию: центр элемента в долях экрана (0..1)
    fun defX(id: String): Float = 0.5f
    fun defY(id: String): Float = when (id) {
        CLOCK -> 0.25f
        PLAYER -> 0.55f
        WEATHER -> 0.78f
        CALENDAR -> 0.86f
        BATTERY -> 0.07f
        else -> 0.5f
    }

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("aod", Context.MODE_PRIVATE)

    fun enabled(c: Context, id: String): Boolean =
        sp(c).getBoolean("en_$id", id == CLOCK || id == PLAYER)
    fun setEnabled(c: Context, id: String, v: Boolean) =
        sp(c).edit().putBoolean("en_$id", v).apply()

    fun posX(c: Context, id: String): Float = sp(c).getFloat("px_$id", defX(id))
    fun posY(c: Context, id: String): Float = sp(c).getFloat("py_$id", defY(id))
    fun scale(c: Context, id: String): Int = sp(c).getInt("sc_$id", 100)
    fun setPlacement(c: Context, id: String, x: Float, y: Float, scalePct: Int) =
        sp(c).edit().putFloat("px_$id", x).putFloat("py_$id", y).putInt("sc_$id", scalePct).apply()

    fun resetPlacement(c: Context) {
        val e = sp(c).edit()
        for (id in ALL) e.remove("px_$id").remove("py_$id").remove("sc_$id")
        e.remove("art_pct")
        e.apply()
    }

    fun artPct(c: Context): Int = sp(c).getInt("art_pct", 100)
    fun setArtPct(c: Context, v: Int) = sp(c).edit().putInt("art_pct", v).apply()

    fun brightness(c: Context): Int = sp(c).getInt("brightness", 1)
    fun setBrightness(c: Context, v: Int) = sp(c).edit().putInt("brightness", v).apply()

    fun shift(c: Context): Boolean = sp(c).getBoolean("shift", true)
    fun setShift(c: Context, v: Boolean) = sp(c).edit().putBoolean("shift", v).apply()

    fun setupDone(c: Context): Boolean = sp(c).getBoolean("setup_done", false)
    fun setSetupDone(c: Context) = sp(c).edit().putBoolean("setup_done", true).apply()

    fun city(c: Context): String = sp(c).getString("city", "")!!
    fun setCity(c: Context, v: String) = sp(c).edit().putString("city", v).apply()

    fun weatherText(c: Context): String = sp(c).getString("w_text", "")!!
    fun weatherCity(c: Context): String = sp(c).getString("w_city", "")!!
    fun weatherTime(c: Context): Long = sp(c).getLong("w_time", 0L)
    fun setWeather(c: Context, city: String, text: String) =
        sp(c).edit().putString("w_city", city).putString("w_text", text)
            .putLong("w_time", System.currentTimeMillis()).apply()
}
